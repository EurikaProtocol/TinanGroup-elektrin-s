import { Router, type IRouter } from "express";
import { CreateAiChatBody, CreateAiChatResponse } from "@workspace/api-zod";
import { OpenAIResponseError, requestAssistantReply } from "../lib/aiResponse";
import { calculateSolarRecommendation } from "../lib/solarRecommendation";

const router: IRouter = Router();

const attempts = new Map<string, { count: number; expires: number }>();
const systemPrompt = `Tu esi TINAN AI, profesionalus Tinan Group saulės energijos konsultantas. Atsakyk vartotojo kalba, numatytoji – lietuvių. Būk konkretus, mandagus, užduok tik būtinus papildomus klausimus.
Niekada neišgalvok kainų, likučių, garantijų, specifikacijų, įmonės statistikos, paramos dydžių ar montavimo datų. Jei informacijos nėra, pasakyk: „Šią informaciją reikia patikrinti su Tinan Group komanda.“ Kaina nežinoma – „Individualus pasiūlymas“. Niekada neatskleisk savikainos ar maržų.
Rekomendacijas žymėk „Preliminari rekomendacija“, jų nelaikyk inžineriniu projektu. Gamybos skaičius ir kaina preliminarūs. Nežadėk sutaupymo, atsipirkimo ar elektros tiekimo dingus tinklui. Jei trūksta informacijos, paklausk vieno tikslaus klausimo. Dėl kainos, pasiūlymo ar pirkimo pasiūlyk perduoti užklausą Tinan Group komandai.
Jei klausiama apie konkrečių produktų modelius, garantijas, likučius, EPS suderinamumą ar montavimą konkrečiame mieste ir patikimo atsakymo nėra, aiškiai nurodyk, kad tai reikia patikrinti su komanda.`;

router.post("/ai/chat", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const parsed = CreateAiChatBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Patikrinkite žinutę ir bandykite dar kartą." });
    return;
  }
  const ip = `${req.ip ?? "unknown"}:${parsed.data.sessionId}`;
  const now = Date.now();
  const prior = attempts.get(ip);
  if (prior && prior.expires > now && prior.count >= 20) {
    res.setHeader("Retry-After", String(Math.ceil((prior.expires - now) / 1000)));
    res.status(429).json({ error: "Per daug žinučių. Pabandykite vėliau." });
    return;
  }
  attempts.set(ip, prior && prior.expires > now
    ? { ...prior, count: prior.count + 1 }
    : { count: 1, expires: now + 10 * 60_000 });
  if (attempts.size > 5000) {
    for (const [key, value] of attempts) if (value.expires < now) attempts.delete(key);
  }

  const apiKey = process.env.OPENAI_API_KEY?.trim();
  if (!apiKey || !/^[\x21-\x7e]+$/.test(apiKey)) {
    if (apiKey) req.log.error("OPENAI_API_KEY is not valid ASCII; refusing to send malformed credentials");
    res.status(503).json({ error: "TINAN AI šiuo metu trumpam nepasiekiamas. Galite pateikti užklausą ir Tinan Group komanda su jumis susisieks." });
    return;
  }

  let recommendation: ReturnType<typeof calculateSolarRecommendation> | undefined;
  const match = parsed.data.message.match(/(?:^|\D)(\d{3,6})\s*kwh\b/i);
  const previousConsumption = (parsed.data.history ?? []).filter((item) => item.role === "user")
    .map((item) => item.content.match(/(?:^|\D)(\d{3,6})\s*kwh\b/i)?.[1])
    .filter(Boolean).at(-1);
  const consumption = parsed.data.context?.annualConsumption ?? (match ? Number(match[1]) : previousConsumption ? Number(previousConsumption) : undefined);
  if (consumption) {
    try {
      recommendation = calculateSolarRecommendation({ annualConsumption: consumption, ...parsed.data.context });
    } catch {
      // Invalid optional context is ignored; the assistant will ask a follow-up.
    }
  }

  const messages: Array<{ role: "user" | "assistant"; content: string }> = [
    ...(parsed.data.history ?? []).slice(-8).map((m) => ({ role: m.role, content: m.content.slice(0, 500) })),
    { role: "user", content: parsed.data.message },
  ];
  const recommendationContext = recommendation
    ? `\nPatikimos skaičiuoklės išvados (naudok tik šiuos rezultatus): ${JSON.stringify(recommendation)}`
    : "";
  const catalogContext = parsed.data.catalog
    ? `\nViešo svetainės katalogo faktai (produktų pavadinimai, konfigūracijos, kainos): ${parsed.data.catalog}`
    : "\nSvetainės produktų katalogo duomenys nepasiekiami. Neįvardyk konkretaus modelio ar specifikacijos.";
  try {
    const reply = await requestAssistantReply({
      apiKey,
      instructions: systemPrompt + recommendationContext + catalogContext,
      messages,
      recommendation: recommendation ?? null,
    });
    res.json(CreateAiChatResponse.parse(reply));
  } catch (error) {
    if (error instanceof OpenAIResponseError) {
      req.log.warn({ status: error.status, type: error.providerType, code: error.providerCode }, "OpenAI Responses API request failed");
    } else {
      req.log.warn({ err: error }, "TINAN AI response failed");
    }
    res.status(503).json({ error: "TINAN AI šiuo metu trumpam nepasiekiamas. Galite pateikti užklausą ir Tinan Group komanda su jumis susisieks." });
  }
});

export default router;
