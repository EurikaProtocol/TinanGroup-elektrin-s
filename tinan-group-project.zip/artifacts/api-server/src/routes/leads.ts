import { Router, type IRouter } from "express";
import { and, eq, gte, sql } from "drizzle-orm";
import { db, leadsTable } from "@workspace/db";
import { CreateLeadBody, CreateLeadResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/leads", async (req, res): Promise<void> => {
  res.setHeader("Cache-Control", "no-store");
  const parsed = CreateLeadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Patikrinkite užklausos laukus ir sutikimą." });
    return;
  }
  const { website: _honeypot, ...input } = parsed.data;
  const data = {
    ...input,
    name: input.name.trim(),
    phone: input.phone.trim(),
    city: input.city.trim(),
    email: input.email.trim().toLowerCase(),
  };
  if (data.name.length < 2 || data.city.length < 2 ||
    !/^[+\d\s().-]{6,32}$/.test(data.phone) ||
    data.phone.replace(/\D/g, "").length < 6) {
    res.status(400).json({ error: "Įveskite vardą, miestą ir galiojantį telefono numerį." });
    return;
  }
  try {
    // Serialize submissions for the same email across instances. No public lead-reading route.
    const lead = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${data.email}))`);
      const recent = await tx.select({ id: leadsTable.id }).from(leadsTable)
        .where(and(eq(leadsTable.email, data.email),
          gte(leadsTable.createdAt, new Date(Date.now() - 15 * 60 * 1000))))
        .limit(3);
      if (recent.length >= 3) return null;
      const [created] = await tx.insert(leadsTable).values(data).returning({ id: leadsTable.id });
      return created;
    });
    if (!lead) {
      res.setHeader("Retry-After", "900");
      res.status(429).json({ error: "Per daug užklausų. Bandykite po 15 minučių." });
      return;
    }
    res.status(201).json(CreateLeadResponse.parse({
      id: lead.id,
      message: "Jūsų užklausa gauta. TINAN GROUP komanda su jumis susisieks.",
    }));
  } catch {
    req.log.error("Failed to persist energy enquiry");
    res.status(503).json({ error: "Užklausos išsaugoti nepavyko. Bandykite dar kartą." });
  }
});

export default router;
