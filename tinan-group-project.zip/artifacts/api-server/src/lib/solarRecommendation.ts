export type RecommendationInput = {
  annualConsumption: number;
  propertyType?: "namas" | "ukis" | "verslas";
  battery?: boolean;
  electricVehicle?: boolean;
  heatPump?: boolean;
};

export function calculateSolarRecommendation(input: RecommendationInput) {
  const { annualConsumption, propertyType = "namas", battery = false, electricVehicle = false, heatPump = false } = input;
  if (!Number.isFinite(annualConsumption) || annualConsumption <= 0 || annualConsumption > 1_000_000) {
    throw new Error("Metinis suvartojimas turi būti nuo 1 iki 1 000 000 kWh.");
  }

  const adjustedConsumption = annualConsumption * (1 + (electricVehicle ? 0.2 : 0) + (heatPump ? 0.25 : 0));
  const business = propertyType === "verslas" || propertyType === "ukis" && adjustedConsumption > 12_000;
  const recommendedKwp = business ? 20
    : adjustedConsumption < 3_000 ? 5
      : adjustedConsumption < 5_000 ? 8
        : adjustedConsumption <= 8_000 ? 10
          : adjustedConsumption <= 12_000 ? 10 : 15;
  const packageSlug = business ? "20kw-business"
    : recommendedKwp <= 5 ? "5kw-start"
      : recommendedKwp <= 8 ? "10kw-popular"
        : recommendedKwp <= 10 ? (battery || adjustedConsumption > 8_000 ? "10kw-hybrid" : "10kw-popular")
          : "15kw-pro";
  const sizeBySlug: Record<string, number | null> = {
    "5kw-start": 5,
    "10kw-popular": 10,
    "10kw-hybrid": 10,
    "15kw-pro": 15,
    "20kw-business": null,
  };
  const systemKwp = sizeBySlug[packageSlug];
  const batteryKwh = battery ? (recommendedKwp >= 15 ? "15–16" : "10–15") : null;

  return {
    packageSlug,
    systemKwp,
    recommendedKwp,
    inverter: battery ? "Hibridinis inverteris (galia tikslinama pagal projektą)" : "Tinklinis inverteris (galia tikslinama pagal projektą)",
    batteryKwh,
    annualProductionKwh: systemKwp ? systemKwp * 1000 : null,
    preliminaryPrice: "Individualus pasiūlymas",
    savings: "Atsipirkimas ir sutaupymas nevertinami be patvirtintos elektros kainos, vartojimo profilio ir individualaus pasiūlymo.",
    note: "Preliminari rekomendacija. Galutinį sprendimą reikia patikrinti pagal stogą, ESO sąlygas ir vartojimo profilį.",
  };
}
