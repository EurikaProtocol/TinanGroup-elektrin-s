import assert from "node:assert/strict";
import test from "node:test";
import { calculateSolarRecommendation } from "./solarRecommendation";
import { requestAssistantReply } from "./aiResponse";

const recommendation = calculateSolarRecommendation({ annualConsumption: 5000 });

const baseOptions = {
  apiKey: "test-key",
  instructions: "test instructions",
  messages: [{ role: "user" as const, content: "5000 kWh per metus" }],
};

test("returns the normal model response without marking it as a fallback", async () => {
  let calls = 0;
  const reply = await requestAssistantReply({
    ...baseOptions,
    recommendation,
    fetcher: async (_url, init) => {
      calls += 1;
      assert.equal(init?.method, "POST");
      return Response.json({
        output: [{ content: [{ type: "output_text", text: "Modelio atsakymas." }] }],
      });
    },
  });

  assert.equal(calls, 1);
  assert.equal(reply.answer, "Modelio atsakymas.");
  assert.equal(reply.fallback, undefined);
  assert.deepEqual(reply.recommendation, recommendation);
});

test("returns a transparent local recommendation on HTTP 429 without retrying", async () => {
  let calls = 0;
  const reply = await requestAssistantReply({
    ...baseOptions,
    recommendation,
    fetcher: async () => {
      calls += 1;
      return Response.json({ error: { type: "insufficient_quota", code: "credit_balance_exhausted" } }, { status: 429 });
    },
  });

  assert.equal(calls, 1);
  assert.equal(reply.fallback, true);
  assert.equal(reply.fallbackReason, "quota_exhausted");
  assert.match(reply.answer, /vietinis taisyklių skaičiuotuvas, ne AI modelis/i);
  assert.match(reply.answer, /10 kWp/);
  assert.match(reply.answer, /Individualus pasiūlymas/);
  assert.deepEqual(reply.recommendation, recommendation);
});

test("detects quota or billing error codes even when the HTTP status is not 429", async () => {
  const reply = await requestAssistantReply({
    ...baseOptions,
    recommendation: null,
    fetcher: async () => Response.json(
      { error: { type: "insufficient_quota", code: "credit_balance_exhausted" } },
      { status: 400 },
    ),
  });

  assert.equal(reply.fallback, true);
  assert.match(reply.answer, /OpenAI API kvota arba užklausų limitas pasiektas/);
  assert.match(reply.answer, /metinį elektros suvartojimą kWh/);
  assert.equal(reply.recommendation, null);
});

test("keeps non-quota provider failures as errors and does not retry", async () => {
  let calls = 0;
  await assert.rejects(
    requestAssistantReply({
      ...baseOptions,
      recommendation: null,
      fetcher: async () => {
        calls += 1;
        return Response.json({ error: { type: "server_error", code: "internal_error" } }, { status: 500 });
      },
    }),
    /HTTP 500/,
  );
  assert.equal(calls, 1);
});
