import type { calculateSolarRecommendation } from "./solarRecommendation";

type Recommendation = ReturnType<typeof calculateSolarRecommendation>;
type ChatMessage = { role: "user" | "assistant"; content: string };
type ProviderError = { type?: unknown; code?: unknown };

export type AssistantReply = {
  answer: string;
  recommendation: Recommendation | null;
  fallback?: true;
  fallbackReason?: "quota_exhausted";
};

export class OpenAIResponseError extends Error {
  constructor(
    readonly status: number,
    readonly providerType?: string,
    readonly providerCode?: string,
  ) {
    super(`OpenAI Responses API returned HTTP ${status}`);
    this.name = "OpenAIResponseError";
  }
}

const quotaErrorCodes = new Set([
  "billing_hard_limit_reached",
  "billing_not_active",
  "credit_balance_exhausted",
  "insufficient_funds",
  "insufficient_quota",
  "quota_exceeded",
]);

export function isQuotaFailure(status: number, error: ProviderError = {}): boolean {
  return status === 429 ||
    error.type === "insufficient_quota" ||
    (typeof error.code === "string" && quotaErrorCodes.has(error.code));
}

export function buildQuotaFallback(recommendation: Recommendation | null): string {
  const notice = "OpenAI API kvota arba užklausų limitas pasiektas. Šį atsakymą parengė vietinis taisyklių skaičiuotuvas, ne AI modelis.";
  if (!recommendation) {
    return `${notice}\n\nKad galėčiau pateikti preliminarią saulės elektrinės rekomendaciją, parašykite metinį elektros suvartojimą kWh. Kaina ir atsipirkimas tikslinami individualiai su Tinan Group komanda.`;
  }

  const systemSize = recommendation.systemKwp
    ? `${recommendation.systemKwp} kWp`
    : `apie ${recommendation.recommendedKwp} kWp, tikslinama pagal projektą`;
  const production = recommendation.annualProductionKwh
    ? `Preliminari metinė gamyba – apie ${recommendation.annualProductionKwh.toLocaleString("lt-LT")} kWh (pagal 1000 kWh/kWp per metus prielaidą).`
    : "Metinė gamyba tikslinama pagal individualų projektą.";
  const battery = recommendation.batteryKwh
    ? `Kaupiklio poreikis preliminariai ${recommendation.batteryKwh} kWh.`
    : "Kaupiklio poreikis nepasirinktas.";

  return `${notice}\n\nPreliminari rekomendacija pagal jūsų pateiktą suvartojimą: ${systemSize}. ${production} ${battery} ${recommendation.inverter}. Kaina – „Individualus pasiūlymas“; sutaupymas ir atsipirkimas šiame skaičiavime nevertinami. ${recommendation.note}`;
}

export async function requestAssistantReply(options: {
  apiKey: string;
  instructions: string;
  messages: ChatMessage[];
  recommendation: Recommendation | null;
  fetcher?: typeof fetch;
}): Promise<AssistantReply> {
  const fetcher = options.fetcher ?? fetch;
  const response = await fetcher("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: { Authorization: `Bearer ${options.apiKey}`, "Content-Type": "application/json" },
    signal: AbortSignal.timeout(25_000),
    body: JSON.stringify({
      model: "gpt-4.1-mini",
      instructions: options.instructions,
      input: options.messages,
      max_output_tokens: 700,
    }),
  });

  if (!response.ok) {
    let providerError: ProviderError = {};
    try {
      const payload = await response.json() as { error?: ProviderError };
      providerError = payload.error ?? {};
    } catch {
      // Keep diagnostics limited to the allowlisted error fields below.
    }
    const providerType = typeof providerError.type === "string" ? providerError.type : undefined;
    const providerCode = typeof providerError.code === "string" ? providerError.code : undefined;

    if (isQuotaFailure(response.status, { type: providerType, code: providerCode })) {
      return {
        answer: buildQuotaFallback(options.recommendation),
        recommendation: options.recommendation,
        fallback: true,
        fallbackReason: "quota_exhausted",
      };
    }
    throw new OpenAIResponseError(response.status, providerType, providerCode);
  }

  const payload = await response.json() as {
    output?: Array<{ content?: Array<{ type?: string; text?: string }> }>;
  };
  const answer = payload.output?.flatMap((item) => item.content ?? [])
    .filter((item) => item.type === "output_text")
    .map((item) => item.text ?? "")
    .join("")
    .trim();
  if (!answer) throw new Error("Empty response");
  return { answer, recommendation: options.recommendation };
}
