import type { Metadata } from 'next';
import { company } from '@/data/company';

export const SITE = company.siteUrl;

export function pageMeta(opts: { title: string; description: string; path: string; image?: string; noindex?: boolean }): Metadata {
  const image = opts.image ?? '/images/hero-house.webp';
  return {
    title: opts.title,
    description: opts.description,
    alternates: { canonical: opts.path },
    openGraph: { title: opts.title, description: opts.description, url: opts.path, siteName: company.name, locale: 'lt_LT', type: 'website', images: [{ url: image }] },
    twitter: { card: 'summary_large_image', title: opts.title, description: opts.description, images: [image] },
    robots: opts.noindex ? { index: false, follow: true } : undefined,
  };
}

const clean = <T extends Record<string, unknown>>(o: T) =>
  Object.fromEntries(Object.entries(o).filter(([, v]) => v !== null && v !== undefined)) as Partial<T>;

export function organizationSchema() {
  const sameAs = company.social.map((s) => s.url).filter(Boolean);
  const address = company.address.city
    ? clean({ '@type': 'PostalAddress', streetAddress: company.address.street, addressLocality: company.address.city, postalCode: company.address.postalCode, addressCountry: company.address.country })
    : undefined;
  return [
    clean({ '@context': 'https://schema.org', '@type': 'Organization', name: company.name, legalName: company.legalName, url: SITE, logo: `${SITE}${company.logo}`, email: company.email, telephone: company.phone, sameAs: sameAs.length ? sameAs : undefined }),
    clean({ '@context': 'https://schema.org', '@type': 'LocalBusiness', name: company.name, url: SITE, image: `${SITE}/images/hero-house.webp`, telephone: company.phone, email: company.email, address, areaServed: company.areaServed, openingHours: company.workingHours }),
  ];
}

export function breadcrumbSchema(items: { name: string; path: string }[]) {
  return {
    '@context': 'https://schema.org', '@type': 'BreadcrumbList',
    itemListElement: items.map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.name, item: `${SITE}${it.path}` })),
  };
}

export function faqSchema(items: { q: string; a: string }[]) {
  return { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: items.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })) };
}

export function serviceSchema(name: string, description: string) {
  return { '@context': 'https://schema.org', '@type': 'Service', name, description, provider: { '@type': 'Organization', name: company.name, url: SITE }, areaServed: company.areaServed };
}
