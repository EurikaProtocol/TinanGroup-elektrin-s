import type { LeadInputPropertyType } from '@workspace/api-client-react';

export type SolarPackage = {
  slug: string;
  power: string;
  name: string;
  tagline: string;
  badge?: string;
  image: string;
  /** Nominal kWp used for production estimates (null for custom sizes). */
  kwp: number | null;
  battery: boolean;
  forProperty: LeadInputPropertyType[];
  components: string[];
  details: {
    modules: string;
    inverter: string;
    battery: string;
    construction: string;
    protections: string;
    monitoring: string;
    installation: string;
    warranty: string;
  };
  upgrades: string[];
  cta: string;
  individual?: boolean;
};

const WARRANTY = 'Gamintojų garantijos sąlygos nurodomos pasiūlyme pagal parinktą įrangą';

export const packages: SolarPackage[] = [
  {
    slug: '5kw-start', power: '5 kW', name: 'START', tagline: 'Puikus pasirinkimas mažesniam namui',
    image: '/images/equipment-ongrid.webp', kwp: 5, battery: false, forProperty: ['namas'],
    components: ['10 × 500 W moduliai', '5 kW inverteris', 'Stogo konstrukcija', 'DC/AC apsaugos', 'Kabeliai', 'Montavimas', 'Paleidimas'],
    details: { modules: '10 × 500 W saulės moduliai (5 kWp)', inverter: '5 kW tinklinis inverteris', battery: 'Nėra (galima papildyti vėliau)', construction: 'Stogo montavimo konstrukcija pagal dangą', protections: 'DC/AC apsaugos, kabeliai', monitoring: 'Inverterio stebėsenos programėlė', installation: 'Montavimas ir paleidimas', warranty: WARRANTY },
    upgrades: ['Paruošimas kaupikliui', 'Išmanusis skaitiklis', 'EV įkrovimo stotelė'], cta: 'Peržiūrėti komplektą',
  },
  {
    slug: '10kw-popular', power: '10 kW', name: 'POPULAR', tagline: 'Geriausias pasirinkimas daugumai namų', badge: 'Populiariausias',
    image: '/images/equipment-ongrid.webp', kwp: 10, battery: false, forProperty: ['namas'],
    components: ['20 × 500 W moduliai', '10 kW inverteris', 'Stogo konstrukcija', 'DC/AC apsaugos', 'Kabeliai', 'Montavimas', 'Paleidimas'],
    details: { modules: '20 × 500 W saulės moduliai (10 kWp)', inverter: '10 kW tinklinis inverteris', battery: 'Nėra (galima papildyti vėliau)', construction: 'Stogo montavimo konstrukcija pagal dangą', protections: 'DC/AC apsaugos, kabeliai', monitoring: 'Inverterio stebėsenos programėlė', installation: 'Montavimas ir paleidimas', warranty: WARRANTY },
    upgrades: ['Hibridinis inverteris vietoj tinklinio', 'Energijos kaupiklis', 'EV įkrovimo stotelė'], cta: 'Peržiūrėti komplektą',
  },
  {
    slug: '10kw-hybrid', power: '10 kW', name: 'HYBRID', tagline: 'Saulė + kaupiklis maksimaliai nepriklausomybei',
    image: '/images/equipment-hybrid.webp', kwp: 10, battery: true, forProperty: ['namas', 'ukis'],
    components: ['20 × 500 W moduliai', '10 kW hibridinis inverteris', 'Dyness kaupiklis', 'Smart Meter', 'Backup / EPS', 'Stogo konstrukcija', 'DC/AC apsaugos', 'Montavimas'],
    details: { modules: '20 × 500 W saulės moduliai (10 kWp)', inverter: '10 kW hibridinis inverteris', battery: 'Dyness kaupiklis (talpa parenkama pagal poreikį)', construction: 'Stogo montavimo konstrukcija pagal dangą', protections: 'DC/AC apsaugos, kabeliai', monitoring: 'Smart Meter ir stebėsenos programėlė', installation: 'Montavimas, Backup/EPS konfigūravimas, paleidimas', warranty: WARRANTY },
    upgrades: ['Didesnė kaupiklio talpa', 'EV įkrovimo stotelė', 'Energijos valdymo integracija'], cta: 'Peržiūrėti komplektą',
  },
  {
    slug: '15kw-pro', power: '15 kW', name: 'PRO', tagline: 'Dideliam suvartojimui ir ateities poreikiams',
    image: '/images/equipment-hybrid.webp', kwp: 15, battery: true, forProperty: ['namas', 'ukis'],
    components: ['24–30 × 500 W moduliai', '15 kW hibridinis inverteris', 'Dyness 15–16 kWh kaupiklis', 'Smart Meter', 'Backup / EPS', 'Stogo konstrukcija', 'Apsaugos', 'Montavimas'],
    details: { modules: '24–30 × 500 W saulės moduliai', inverter: '15 kW hibridinis inverteris', battery: 'Dyness 15–16 kWh kaupiklis', construction: 'Stogo montavimo konstrukcija pagal dangą', protections: 'DC/AC apsaugos, kabeliai', monitoring: 'Smart Meter ir stebėsenos programėlė', installation: 'Montavimas, Backup/EPS konfigūravimas, paleidimas', warranty: WARRANTY },
    upgrades: ['EV įkrovimo stotelė', 'Šilumos siurblio valdymo integracija', 'Papildomi kaupiklio moduliai'], cta: 'Peržiūrėti komplektą',
  },
  {
    slug: '20kw-business', power: '20+ kW', name: 'BUSINESS', tagline: 'Verslui, ūkiui ir dideliems objektams',
    image: '/images/commercial-roof.webp', kwp: null, battery: true, forProperty: ['verslas', 'ukis'], individual: true,
    components: ['20+ kWp saulės moduliai', '20–50 kW inverteris', 'Dyness / KSTAR kaupikliai', 'Komercinė konstrukcija', 'Monitoringas', 'Energijos valdymas', 'Pilnas montavimas'],
    details: { modules: '20+ kWp saulės moduliai', inverter: '20–50 kW inverteris', battery: 'Dyness / KSTAR kaupikliai pagal projektą', construction: 'Komercinė stogo arba antžeminė konstrukcija', protections: 'Projektinės DC/AC apsaugos', monitoring: 'Monitoringas ir energijos valdymas', installation: 'Projektavimas, pilnas montavimas, paleidimas', warranty: WARRANTY },
    upgrades: ['EV įkrovimo infrastruktūra', 'Apkrovų valdymas', 'Išplėtimas etapais'], cta: 'Gauti individualų pasiūlymą',
  },
];

export const getPackage = (slug: string) => packages.find((p) => p.slug === slug);
export const packageTitle = (p: SolarPackage) => `${p.power} ${p.name}`;
