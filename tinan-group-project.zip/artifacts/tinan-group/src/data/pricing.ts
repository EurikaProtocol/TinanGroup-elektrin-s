/**
 * Central pricing engine. Every price on the site is derived here.
 * A price entry with `net: null` is UNKNOWN → UI shows "Individualus pasiūlymas".
 * NO prices are set by default — TINAN GROUP must fill in real numbers.
 */
export const pricingConfig = {
  currency: 'EUR',
  vatRate: 0.21, // Lithuanian standard VAT rate; edit if a different rate applies
  locale: 'lt-LT',
};

export type PriceInput = {
  /** Equipment net cost (EUR, excl. VAT). null = unknown. */
  net: number | null;
  /** Installation net cost (EUR, excl. VAT). */
  installation?: number | null;
  /** Margin as fraction (0.15 = 15%). */
  margin?: number;
  /** Discount as fraction applied after margin. */
  discount?: number;
  /** Show "Nuo" prefix (starting price). */
  from?: boolean;
};

export type PriceBreakdown = { net: number; vat: number; total: number; from: boolean };

export function computePrice(p: PriceInput | undefined | null): PriceBreakdown | null {
  if (!p || p.net == null || p.installation === null) return null;
  if (!Number.isFinite(p.net) || p.net < 0 ||
      (p.installation !== undefined && (!Number.isFinite(p.installation) || p.installation < 0)) ||
      (p.margin !== undefined && (!Number.isFinite(p.margin) || p.margin < 0)) ||
      (p.discount !== undefined && (!Number.isFinite(p.discount) || p.discount < 0 || p.discount > 1))) {
    throw new Error('Invalid pricing configuration');
  }
  const cents = (value: number) => Math.round((value + Number.EPSILON) * 100) / 100;
  const base = p.net + (p.installation ?? 0);
  const withMargin = base * (1 + (p.margin ?? 0));
  const net = cents(withMargin * (1 - (p.discount ?? 0)));
  const vat = cents(net * pricingConfig.vatRate);
  return { net, vat, total: cents(net + vat), from: !!p.from };
}

export function formatEur(n: number) {
  return new Intl.NumberFormat(pricingConfig.locale, { style: 'currency', currency: pricingConfig.currency, minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 }).format(n);
}

export const INDIVIDUAL_OFFER = 'Individualus pasiūlymas';

/** Package prices keyed by package slug. Fill `net` to publish a price. */
export const packagePrices: Record<string, PriceInput> = {
  '5kw-start': { net: null, installation: null, margin: 0, discount: 0, from: true },
  '10kw-popular': { net: null, installation: null, margin: 0, discount: 0, from: true },
  '10kw-hybrid': { net: null, installation: null, margin: 0, discount: 0, from: true },
  '15kw-pro': { net: null, installation: null, margin: 0, discount: 0, from: true },
  '20kw-business': { net: null, installation: null, margin: 0, discount: 0, from: true },
};

/** Product prices keyed by product id. */
export const productPrices: Record<string, PriceInput> = {};

/** Assumptions used for estimates. null electricity price hides savings figures. */
export const estimateConfig = {
  /** Typical annual yield in Lithuania, kWh per installed kWp (editable assumption). */
  yieldPerKwp: 1000,
  /** Electricity price EUR/kWh incl. VAT. null = savings shown as "skaičiuojama individualiai". */
  electricityPrice: null as number | null,
  /** Share of production used directly (without / with battery). */
  selfConsumption: { withoutBattery: 0.35, withBattery: 0.7 },
};
