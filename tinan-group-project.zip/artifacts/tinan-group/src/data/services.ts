export type ServiceIcon = 'ruler' | 'hammer' | 'battery' | 'cpu' | 'zap' | 'file' | 'landmark' | 'activity' | 'shield' | 'wrench';
export type Service = { slug: string; icon: ServiceIcon; title: string; text: string };

export const services: Service[] = [
  { slug: 'projektavimas', icon: 'ruler', title: 'Saulės elektrinių projektavimas', text: 'Stogo, šešėlių ir suvartojimo analizė, modulių išdėstymas ir techninis projektas.' },
  { slug: 'montavimas', icon: 'hammer', title: 'Montavimas', text: 'Konstrukcijos, moduliai, kabeliai ir apsaugos — tvarkingai ir pagal normas.' },
  { slug: 'kaupikliu-montavimas', icon: 'battery', title: 'Kaupiklių montavimas', text: 'Kaupiklio prijungimas prie esamos ar naujos sistemos, Backup/EPS konfigūravimas.' },
  { slug: 'inverteriu-montavimas', icon: 'cpu', title: 'Inverterių montavimas', text: 'Tinklinių ir hibridinių inverterių įrengimas, keitimas ir derinimas.' },
  { slug: 'elektros-darbai', icon: 'zap', title: 'Elektros darbai', text: 'Skydų modernizavimas, įžeminimas, EV stotelių pajungimas.' },
  { slug: 'eso-dokumentacija', icon: 'file', title: 'ESO dokumentacija', text: 'Prijungimo sąlygos, paraiškos ir derinimai su skirstomuoju tinklu.' },
  { slug: 'apva-dokumentacija', icon: 'landmark', title: 'APVA dokumentacija', text: 'Pagalba rengiant dokumentus paramai gauti, kai kvietimai aktyvūs.' },
  { slug: 'monitoringas', icon: 'activity', title: 'Monitoringas', text: 'Nuotolinė gamybos stebėsena ir pranešimai apie nukrypimus.' },
  { slug: 'garantinis', icon: 'shield', title: 'Garantinis aptarnavimas', text: 'Garantinių atvejų sprendimas kartu su įrangos gamintojais.' },
  { slug: 'pogarantinis', icon: 'wrench', title: 'Pogarantinis aptarnavimas', text: 'Patikros, valymas, remontas ir sistemos plėtra po garantijos.' },
];

export const processSteps = [
  { n: '01', title: 'Poreikio analizė', text: 'Suvartojimas, planai, biudžetas.' },
  { n: '02', title: 'Objekto įvertinimas', text: 'Stogas, orientacija, šešėliai, elektros skydas.' },
  { n: '03', title: 'Sistemos projektavimas', text: 'Įranga ir išdėstymas pagal realius duomenis.' },
  { n: '04', title: 'Pasiūlymas', text: 'Aiški komplektacija ir kaina be paslėptų eilučių.' },
  { n: '05', title: 'Montavimas', text: 'Sertifikuota komanda, tvarkinga darbo vieta.' },
  { n: '06', title: 'ESO / dokumentai', text: 'Prijungimas ir paramos dokumentai.' },
  { n: '07', title: 'Paleidimas', text: 'Testavimas, programėlė, apmokymas.' },
  { n: '08', title: 'Monitoringas ir aptarnavimas', text: 'Esame šalia visą sistemos gyvavimą.' },
];
