/**
 * Product catalog. Specific model names / datasheet specs are NOT invented:
 * `model: null` renders "Modelis tikslinamas". Fill from manufacturer datasheets.
 * Prices live in data/pricing.ts → productPrices[id].
 */
export type ProductCategory = 'moduliai' | 'inverteriai' | 'kaupikliai' | 'konstrukcijos' | 'apsaugos' | 'ev' | 'priedai';
export type InverterType = 'hibridinis' | 'tinklinis' | 'komercinis' | 'lv' | 'hv';
export type Availability = 'sandelyje' | 'uzsakymui' | 'tikslinama';

export type Product = {
  id: string;
  category: ProductCategory;
  brand: string;
  model: string | null;
  title: string;
  image: string;
  powerKw?: number;
  capacityKwh?: number;
  inverterTypes?: InverterType[];
  availability: Availability;
  specs?: { label: string; value: string | null }[];
};

export const categories: { id: ProductCategory; label: string }[] = [
  { id: 'moduliai', label: 'Saulės moduliai' },
  { id: 'inverteriai', label: 'Inverteriai' },
  { id: 'kaupikliai', label: 'Kaupikliai' },
  { id: 'konstrukcijos', label: 'Konstrukcijos' },
  { id: 'apsaugos', label: 'Elektros apsaugos' },
  { id: 'ev', label: 'EV įkrovimo stotelės' },
  { id: 'priedai', label: 'Priedai' },
];

export const inverterTypeLabels: Record<InverterType, { label: string; text: string }> = {
  hibridinis: { label: 'Hibridiniai', text: 'Saulė, kaupiklis ir tinklas viename įrenginyje. Backup/EPS funkcija nutrūkus tinklui.' },
  tinklinis: { label: 'Tinkliniai (on-grid)', text: 'Paprasčiausias ir efektyviausias sprendimas, kai kaupiklis neplanuojamas.' },
  komercinis: { label: 'Komerciniai', text: 'Trifaziai didelės galios inverteriai verslo ir ūkio objektams.' },
  lv: { label: 'Žemos įtampos baterijoms', text: 'Suderinami su 48 V kaupiklių sistemomis — lanksčiai plečiama talpa.' },
  hv: { label: 'Aukštos įtampos baterijoms', text: 'Aukštos įtampos kaupikliams — mažesni nuostoliai, didesnė galia.' },
};

export const availabilityLabels: Record<Availability, string> = {
  sandelyje: 'Sandėlyje',
  uzsakymui: 'Užsakymui',
  tikslinama: 'Prieinamumas tikslinamas',
};

const datasheet = (labels: string[]) => labels.map((label) => ({ label, value: null }));

export const products: Product[] = [
  { id: 'mod-500', category: 'moduliai', brand: 'Tikslinama', model: null, title: 'Saulės modulis 500 W', image: '/images/equipment-ongrid.webp', powerKw: 0.5, availability: 'tikslinama', specs: datasheet(['Efektyvumas', 'Matmenys', 'Garantija']) },
  { id: 'inv-solis-hybrid-10', category: 'inverteriai', brand: 'Solis', model: null, title: 'Hibridinis inverteris 10 kW', image: '/images/equipment-hybrid.webp', powerKw: 10, inverterTypes: ['hibridinis', 'hv'], availability: 'tikslinama', specs: datasheet(['Fazės', 'MPPT', 'Baterijos įtampa', 'Garantija']) },
  { id: 'inv-solax-5', category: 'inverteriai', brand: 'SolaX', model: null, title: 'Tinklinis inverteris 5 kW', image: '/images/equipment-ongrid.webp', powerKw: 5, inverterTypes: ['tinklinis'], availability: 'tikslinama', specs: datasheet(['Fazės', 'MPPT', 'Garantija']) },
  { id: 'inv-solax-10', category: 'inverteriai', brand: 'SolaX', model: null, title: 'Tinklinis inverteris 10 kW', image: '/images/equipment-ongrid.webp', powerKw: 10, inverterTypes: ['tinklinis'], availability: 'tikslinama', specs: datasheet(['Fazės', 'MPPT', 'Garantija']) },
  { id: 'inv-hybrid-15', category: 'inverteriai', brand: 'Tikslinama', model: null, title: 'Hibridinis inverteris 15 kW', image: '/images/equipment-hybrid.webp', powerKw: 15, inverterTypes: ['hibridinis', 'lv'], availability: 'tikslinama', specs: datasheet(['Fazės', 'MPPT', 'Baterijos įtampa', 'Garantija']) },
  { id: 'inv-commercial', category: 'inverteriai', brand: 'Tikslinama', model: null, title: 'Komercinis inverteris 20–50 kW', image: '/images/commercial-roof.webp', powerKw: 50, inverterTypes: ['komercinis'], availability: 'tikslinama', specs: datasheet(['Fazės', 'MPPT', 'Garantija']) },
  { id: 'bat-dyness-10', category: 'kaupikliai', brand: 'Dyness', model: null, title: 'Dyness kaupiklis 10,24 kWh', image: '/images/equipment-hybrid.webp', capacityKwh: 10.24, availability: 'tikslinama', specs: datasheet(['Chemija', 'Įtampa', 'Ciklai', 'Garantija']) },
  { id: 'bat-dyness-15', category: 'kaupikliai', brand: 'Dyness', model: null, title: 'Dyness kaupiklis 15–16 kWh', image: '/images/equipment-hybrid.webp', capacityKwh: 15.4, availability: 'tikslinama', specs: datasheet(['Chemija', 'Įtampa', 'Ciklai', 'Garantija']) },
  { id: 'bat-kstar', category: 'kaupikliai', brand: 'KSTAR', model: null, title: 'KSTAR energijos kaupiklis', image: '/images/battery-garage.webp', availability: 'tikslinama', specs: datasheet(['Talpa', 'Įtampa', 'Ciklai', 'Garantija']) },
  { id: 'con-roof', category: 'konstrukcijos', brand: 'Corab', model: null, title: 'Šlaitinio stogo konstrukcija', image: '/images/installation.webp', availability: 'tikslinama' },
  { id: 'con-flat', category: 'konstrukcijos', brand: 'Tikslinama', model: null, title: 'Plokščio stogo / komercinė konstrukcija', image: '/images/commercial-roof.webp', availability: 'tikslinama' },
  { id: 'prot-dcac', category: 'apsaugos', brand: 'Tikslinama', model: null, title: 'DC/AC apsaugų komplektas', image: '/images/installation.webp', availability: 'tikslinama' },
  { id: 'ev-11', category: 'ev', brand: 'Tikslinama', model: null, title: 'EV įkrovimo stotelė 11 kW', image: '/images/battery-garage.webp', powerKw: 11, availability: 'tikslinama' },
  { id: 'acc-meter', category: 'priedai', brand: 'Tikslinama', model: null, title: 'Smart Meter', image: '/images/equipment-hybrid.webp', availability: 'tikslinama' },
];
