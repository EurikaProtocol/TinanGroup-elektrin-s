/**
 * Company information — single source of truth.
 * Values set to `null` are UNKNOWN and must be filled in by TINAN GROUP.
 * The UI renders a clearly labelled placeholder for any null value and
 * omits null values from structured data (schema.org).
 * Future CMS: map this object 1:1 to a "Company" singleton document.
 */
export type SocialLink = { id: 'facebook' | 'instagram' | 'youtube'; label: string; url: string | null };

export const company = {
  name: 'TINAN GROUP',
  legalName: null as string | null,
  companyCode: null as string | null,
  vatCode: null as string | null,
  tagline: 'Saulės elektrinių montavimas',
  siteUrl: (process.env.NEXT_PUBLIC_SITE_URL || 'https://tinangroup.com').replace(/\/$/, ''),
  logo: '/images/logo.png',
  phone: '+37069685605',
  email: 'info@tinangroup.com',
  address: {
    street: null as string | null,
    city: null as string | null,
    postalCode: null as string | null,
    country: 'LT',
  },
  workingHours: null as string | null,
  /** Google Maps embed URL (https://www.google.com/maps/embed?...). Null hides the map. */
  mapEmbedUrl: null as string | null,
  areaServed: 'Lietuva',
  social: [
    { id: 'facebook', label: 'Facebook', url: null },
    { id: 'instagram', label: 'Instagram', url: null },
    { id: 'youtube', label: 'YouTube', url: null },
  ] as SocialLink[],
};

/** Placeholder text shown wherever a company value is not yet configured. */
export const PLACEHOLDER = 'Bus patikslinta';

/**
 * Trust points. `value` is an editable claim; null means the figure is not
 * yet confirmed and only the label is shown.
 */
export const trustPoints: { id: string; icon: 'trophy' | 'users' | 'shield' | 'wrench' | 'file' | 'sliders'; title: string; value: string | null; text: string }[] = [
  { id: 'experience', icon: 'trophy', title: 'metų patirtis', value: null, text: 'Patirties metai bus nurodyti patvirtinus įmonės duomenis.' },
  { id: 'certified', icon: 'users', title: 'Sertifikuoti montuotojai', value: null, text: 'Darbus atlieka kvalifikuoti elektros ir montavimo specialistai.' },
  { id: 'quality', icon: 'shield', title: 'Aukščiausios kokybės įranga', value: null, text: 'Dirbame su patikimų gamintojų moduliais, inverteriais ir kaupikliais.' },
  { id: 'warranty', icon: 'wrench', title: 'Garantinis aptarnavimas', value: null, text: 'Lieka ryšys ir po paleidimo: aptarnavimas, diagnostika, pagalba.' },
  { id: 'docs', icon: 'file', title: 'Pagalba su dokumentais', value: null, text: 'ESO prijungimo ir APVA paramos dokumentus parengiame kartu su jumis.' },
  { id: 'custom', icon: 'sliders', title: 'Individualūs sprendimai', value: null, text: 'Sistemą parenkame pagal jūsų suvartojimą, stogą ir planus.' },
];
