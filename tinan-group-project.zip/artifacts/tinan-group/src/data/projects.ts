/**
 * Projects gallery. ONLY add real, client-approved projects here.
 * Entries with `illustrative: true` are clearly labelled example configurations
 * with illustration imagery — they are NOT completed TINAN GROUP projects.
 * Remove them once real projects are published.
 */
export type ProjectCategory = 'namai' | 'ukiai' | 'verslas' | 'kaupikliai';
export type Project = {
  id: string;
  categories: ProjectCategory[];
  title: string;
  image: string;
  systemSize: string;
  location: string | null;
  panelCount: string;
  inverter: string;
  battery: string | null;
  installationType: string;
  illustrative: boolean;
};

export const projectFilters: { id: ProjectCategory; label: string }[] = [
  { id: 'namai', label: 'Namai' },
  { id: 'ukiai', label: 'Ūkiai' },
  { id: 'verslas', label: 'Verslas' },
  { id: 'kaupikliai', label: 'Kaupikliai' },
];

export const projects: Project[] = [
  { id: 'ex-home-hybrid', categories: ['namai', 'kaupikliai'], title: 'Privatus namas su kaupikliu', image: '/images/hero-house.webp', systemSize: '10 kWp', location: null, panelCount: '20 modulių', inverter: 'Hibridinis', battery: '15,4 kWh', installationType: 'Šlaitinis stogas', illustrative: true },
  { id: 'ex-farm', categories: ['ukiai'], title: 'Ūkio pastatas', image: '/images/farm.webp', systemSize: '20+ kWp', location: null, panelCount: 'Pagal projektą', inverter: 'Trifazis tinklinis', battery: null, installationType: 'Ūkinio pastato stogas', illustrative: true },
  { id: 'ex-business', categories: ['verslas'], title: 'Komercinis stogas', image: '/images/commercial-roof.webp', systemSize: '20–50 kWp', location: null, panelCount: 'Pagal projektą', inverter: 'Komercinis', battery: null, installationType: 'Plokščias stogas', illustrative: true },
  { id: 'ex-garage', categories: ['namai', 'kaupikliai'], title: 'Kaupiklis ir EV įkrova', image: '/images/battery-garage.webp', systemSize: 'Esama sistema', location: null, panelCount: '—', inverter: 'Hibridinis', battery: 'Pagal poreikį', installationType: 'Kaupiklio papildymas', illustrative: true },
];
