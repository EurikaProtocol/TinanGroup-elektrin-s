export const faq = [
  { q: 'Kokios galios saulės elektrinės man reikia?', a: 'Pradinis atskaitos taškas — metinis elektros suvartojimas. Įvertiname ir planus: elektromobilį, šilumos siurblį, namo plėtrą. Greitą rekomendaciją pateikia mūsų skaičiuoklė, tikslų sprendimą — specialistas.' },
  { q: 'Ar verta rinktis kaupiklį?', a: 'Kaupiklis leidžia dienos perteklių naudoti vakare ir naktį, o hibridinė sistema su Backup/EPS gali maitinti svarbiausius prietaisus dingus tinklui.' },
  { q: 'Ar padedate su ESO ir APVA dokumentais?', a: 'Taip. Parengiame ESO prijungimo dokumentus ir padedame su APVA paramos paraiška, kai kvietimai yra aktyvūs.' },
  { q: 'Kodėl kainos nurodomos kaip individualus pasiūlymas?', a: 'Galutinė kaina priklauso nuo stogo, įrangos prieinamumo ir montavimo sąlygų. Pateikiame aiškų pasiūlymą su NET, PVM ir galutine suma.' },
  { q: 'Ar galima kaupiklį pridėti vėliau?', a: 'Taip, jei sistema suprojektuota su hibridiniu inverteriu arba numatyta plėtra. Tai aptariame projektavimo etape.' },
];
