import type { LeadInputPropertyType } from '@workspace/api-client-react';

/** Configurable recommendation engine for the 5-question calculator. */
export const consumptionBands = [
  { id: 'lt3', label: '< 3 000 kWh', kwp: 4 },
  { id: '3-5', label: '3 000–5 000 kWh', kwp: 5 },
  { id: '5-8', label: '5 000–8 000 kWh', kwp: 8 },
  { id: '8-12', label: '8 000–12 000 kWh', kwp: 11 },
  { id: '12p', label: '12 000+ kWh', kwp: 15 },
] as const;

export const calculatorRules = {
  evAddKwp: 2.5,
  heatPumpAddKwp: 3,
  businessMinKwp: 20,
  /** Battery capacity suggestions by final kWp threshold (ascending). */
  batteryByKwp: [
    { maxKwp: 6, kwh: '10,24 kWh' },
    { maxKwp: 12, kwh: '15,4 kWh' },
    { maxKwp: 999, kwh: '15–16 kWh ir daugiau' },
  ],
  /** Package selection rules evaluated in order. */
  pick(kwp: number, battery: boolean, property: LeadInputPropertyType): string {
    if (property === 'verslas' || kwp > 16) return '20kw-business';
    if (kwp > 11) return '15kw-pro';
    if (battery) return '10kw-hybrid';
    if (kwp > 6) return '10kw-popular';
    return '5kw-start';
  },
};

export type CalcAnswers = { band: string; battery: boolean; property: LeadInputPropertyType; ev: boolean; heatPump: boolean };

export function recommend(a: CalcAnswers) {
  const band = consumptionBands.find((b) => b.id === a.band) ?? consumptionBands[1];
  let kwp = band.kwp + (a.ev ? calculatorRules.evAddKwp : 0) + (a.heatPump ? calculatorRules.heatPumpAddKwp : 0);
  if (a.property === 'verslas') kwp = Math.max(kwp, calculatorRules.businessMinKwp);
  kwp = Math.round(kwp * 2) / 2;
  const slug = calculatorRules.pick(kwp, a.battery, a.property);
  const battery = a.battery ? calculatorRules.batteryByKwp.find((b) => kwp <= b.maxKwp)?.kwh ?? null : null;
  const invLow = Math.max(5, Math.round(kwp / 5) * 5);
  const inverter = kwp >= 20 ? '20–50 kW inverteris' : `${invLow}–${invLow + 5} kW ${a.battery ? 'hibridinis ' : ''}inverteris`;
  return { slug, kwp, battery, inverter, bandLabel: band.label };
}
