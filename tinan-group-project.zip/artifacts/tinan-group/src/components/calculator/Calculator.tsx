'use client';
import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, ArrowRight, Home, Tractor, Building2, RotateCcw, Sun } from 'lucide-react';
import type { LeadInputPropertyType } from '@workspace/api-client-react';
import { t } from '@/i18n';
import { consumptionBands, recommend } from '@/data/calculator';
import { getPackage, packageTitle } from '@/data/packages';
import { useLeadModal } from '@/components/forms/LeadModal';
import { Counter } from '@/components/Reveal';

type Opt<T> = { v: T; label: string; sub?: string; icon?: React.ReactNode };

export function Calculator() {
  const [step, setStep] = useState(0);
  const [band, setBand] = useState<string | null>(null);
  const [battery, setBattery] = useState<boolean | null>(null);
  const [property, setProperty] = useState<LeadInputPropertyType | null>(null);
  const [ev, setEv] = useState<boolean | null>(null);
  const [heatPump, setHeatPump] = useState<boolean | null>(null);
  const { open } = useLeadModal();

  const yn: Opt<boolean>[] = [{ v: false, label: t.calc.no }, { v: true, label: t.calc.yes }];
  const questions = [
    { q: t.calc.q1, value: band, set: setBand, opts: consumptionBands.map((b) => ({ v: b.id, label: b.label })) as Opt<string>[] },
    { q: t.calc.q2, value: battery, set: setBattery, opts: [{ v: false, label: t.calc.no, sub: 'Tik saulės elektrinė' }, { v: true, label: t.calc.yes, sub: 'Su energijos kaupikliu' }] as Opt<boolean>[] },
    { q: t.calc.q3, value: property, set: setProperty, opts: [
      { v: 'namas', label: t.property.namas, icon: <Home className="h-5 w-5" /> },
      { v: 'ukis', label: t.property.ukis, icon: <Tractor className="h-5 w-5" /> },
      { v: 'verslas', label: t.property.verslas, icon: <Building2 className="h-5 w-5" /> },
    ] as Opt<LeadInputPropertyType>[] },
    { q: t.calc.q4, value: ev, set: setEv, opts: yn },
    { q: t.calc.q5, value: heatPump, set: setHeatPump, opts: yn },
  ] as const;

  const done = step >= questions.length;
  const result = done && band && battery !== null && property && ev !== null && heatPump !== null ? recommend({ band, battery, property, ev, heatPump }) : null;
  const pkg = result ? getPackage(result.slug) : undefined;
  const reset = () => { setStep(0); setBand(null); setBattery(null); setProperty(null); setEv(null); setHeatPump(null); };

  const choose = (i: number, v: unknown) => {
    (questions[i].set as (x: unknown) => void)(v);
    window.setTimeout(() => setStep(i + 1), 160);
  };

  return (
    <div className="grid overflow-hidden rounded-[28px] border border-border bg-white shadow-[0_30px_80px_-50px_rgba(120,60,0,.45)] lg:grid-cols-[1fr_1.35fr]" data-testid="calculator">
      <div className="relative flex flex-col justify-between gap-8 bg-[#FFF3E2] p-7 sm:p-10">
        <div>
          <span className="accent-line mb-5" />
          <h2 className="font-display text-[clamp(1.8rem,3.4vw,2.8rem)] font-extrabold uppercase leading-[1.02]">{t.calc.title1} <span className="text-[#F28C00]">{t.calc.title2}</span></h2>
          <p className="mt-4 max-w-sm text-[15px] leading-relaxed text-foreground/70">Penki klausimai. Rekomendacija paremta jūsų suvartojimu ir planais — tikslų sprendimą patvirtins specialistas.</p>
        </div>
        <ol className="flex gap-2" aria-label="Klausimų eiga">
          {questions.map((_, i) => (
            <li key={i} className="h-1.5 flex-1 overflow-hidden rounded-full bg-black/10">
              <span className="block h-full origin-left rounded-full bg-[#F28C00] transition-transform duration-500" style={{ transform: `scaleX(${step > i ? 1 : 0})` }} />
            </li>
          ))}
        </ol>
        <Sun className="pointer-events-none absolute -bottom-10 -right-10 h-48 w-48 text-[#F28C00]/12" strokeWidth={1} aria-hidden />
      </div>

      <div className="p-6 sm:p-10" aria-live="polite">
        {!done ? (
          <div key={step} className="step-in">
            <p className="font-mono text-[12px] font-semibold text-[#F28C00]">{String(step + 1).padStart(2, '0')} / {String(questions.length).padStart(2, '0')}</p>
            <h3 className="mt-2 font-display text-[22px] font-bold sm:text-[26px]">{questions[step].q}</h3>
            <div className={`mt-6 grid gap-3 ${questions[step].opts.length > 3 ? 'grid-cols-1 sm:grid-cols-2' : questions[step].opts.length === 3 ? 'grid-cols-3' : 'grid-cols-2'}`} role="radiogroup" aria-label={questions[step].q}>
              {(questions[step].opts as Opt<unknown>[]).map((o) => {
                const selected = questions[step].value === o.v;
                return (
                  <button key={String(o.v)} type="button" role="radio" aria-checked={selected} onClick={() => choose(step, o.v)}
                    className={`flex min-h-[64px] flex-col items-center justify-center gap-1.5 rounded-2xl border-2 px-4 py-4 text-center transition active:scale-[.98] ${selected ? 'border-[#F28C00] bg-[#FFF3E2]' : 'border-border bg-white hover:border-[#F28C00]/60'}`}
                    data-testid={`option-calc-${step}-${String(o.v)}`}>
                    {o.icon && <span className="text-[#F28C00]">{o.icon}</span>}
                    <span className="text-[16px] font-bold">{o.label}</span>
                    {o.sub && <span className="text-[12.5px] text-muted-foreground">{o.sub}</span>}
                  </button>
                );
              })}
            </div>
            <div className="mt-8 flex items-center justify-between">
              <button type="button" onClick={() => setStep((s) => Math.max(0, s - 1))} disabled={step === 0} className="inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground disabled:opacity-30" data-testid="button-calc-back"><ArrowLeft className="h-4 w-4" /> {t.calc.back}</button>
              {questions[step].value !== null && <button type="button" onClick={() => setStep(step + 1)} className="inline-flex items-center gap-1.5 text-sm font-bold text-[#F28C00]" data-testid="button-calc-next">{t.calc.next} <ArrowRight className="h-4 w-4" /></button>}
            </div>
          </div>
        ) : result && pkg ? (
          <div className="step-in" data-testid="calc-result">
            <p className="eyebrow text-muted-foreground">{t.calc.result}</p>
            <p className="mt-2 font-display text-[clamp(2.2rem,5vw,3.6rem)] font-extrabold uppercase leading-none" data-testid="text-calc-package">{pkg.power} <span className="text-[#F28C00]">{pkg.name}</span></p>
            <dl className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="rounded-2xl bg-[#F5F3EF] p-4"><dt className="text-[12px] font-semibold uppercase tracking-wider text-muted-foreground">Galia</dt><dd className="mt-1 font-display text-2xl font-extrabold"><Counter value={result.kwp} decimals={result.kwp % 1 ? 1 : 0} /> kWp</dd></div>
              <div className="rounded-2xl bg-[#F5F3EF] p-4"><dt className="text-[12px] font-semibold uppercase tracking-wider text-muted-foreground">Kaupiklis</dt><dd className="mt-1 font-display text-xl font-extrabold">{result.battery ?? 'Nereikia'}</dd></div>
              <div className="rounded-2xl bg-[#F5F3EF] p-4"><dt className="text-[12px] font-semibold uppercase tracking-wider text-muted-foreground">Inverteris</dt><dd className="mt-1 font-display text-lg font-extrabold leading-tight">{result.inverter}</dd></div>
            </dl>
            <p className="mt-4 text-[12.5px] text-muted-foreground">Preliminari rekomendacija. Galutinė konfigūracija priklauso nuo stogo, orientacijos ir elektros įvado.</p>
            <div className="mt-7 flex flex-col gap-3 sm:flex-row">
              <button type="button" onClick={() => open({ title: `Rekomendacija: ${packageTitle(pkg)}`, prefill: { propertyType: property ?? 'namas', annualConsumption: result.bandLabel, systemSize: `${result.kwp} kWp`, solution: packageTitle(pkg), battery: !!battery, message: `Skaičiuoklė: ${result.inverter}${result.battery ? `, kaupiklis ${result.battery}` : ''}${ev ? ', planuojamas elektromobilis' : ''}${heatPump ? ', šilumos siurblys' : ''}.` } })}
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-[#F28C00] px-6 py-4 text-[13px] font-extrabold uppercase tracking-wider text-black hover:bg-[#ff9a14]" data-testid="button-calc-offer">
                {t.cta.individual} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
              </button>
              <Link href={`/saules-elektrines/${pkg.slug}`} className="inline-flex items-center justify-center rounded-full border border-border px-6 py-4 text-[13px] font-bold uppercase tracking-wider hover:border-[#F28C00]" data-testid="link-calc-package">Komplekto detalės</Link>
            </div>
            <button type="button" onClick={reset} className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground" data-testid="button-calc-restart"><RotateCcw className="h-4 w-4" /> {t.calc.restart}</button>
          </div>
        ) : (
          <button type="button" onClick={reset} className="text-sm font-semibold">{t.calc.restart}</button>
        )}
      </div>
    </div>
  );
}
