'use client';
import { useMemo, useState } from 'react';
import Image from 'next/image';
import { Search, SlidersHorizontal, X, PackageSearch } from 'lucide-react';
import { products, categories, availabilityLabels, type ProductCategory, type Product } from '@/data/products';
import { productPrices, computePrice } from '@/data/pricing';
import { PriceTag } from './PriceTag';
import { LeadButton } from '@/components/forms/LeadModal';

const powerRanges = [
  { id: 'all', label: 'Visos galios', test: () => true },
  { id: 'lt6', label: 'iki 6 kW', test: (p: Product) => p.powerKw != null && p.powerKw <= 6 },
  { id: '6-15', label: '6–15 kW', test: (p: Product) => p.powerKw != null && p.powerKw > 6 && p.powerKw <= 15 },
  { id: 'gt15', label: '15 kW+', test: (p: Product) => p.powerKw != null && p.powerKw > 15 },
];
const capRanges = [
  { id: 'all', label: 'Bet kokia talpa', test: () => true },
  { id: 'lt12', label: 'iki 12 kWh', test: (p: Product) => p.capacityKwh != null && p.capacityKwh <= 12 },
  { id: 'gt12', label: '12 kWh+', test: (p: Product) => p.capacityKwh != null && p.capacityKwh > 12 },
];

const sel = 'w-full rounded-xl border border-input bg-white px-3.5 py-2.5 text-sm outline-none focus:border-[#F28C00] focus:ring-4 focus:ring-[#F28C00]/15';

export function ProductCatalog({ initialCategory = 'all', lockCategory = false }: { initialCategory?: ProductCategory | 'all'; lockCategory?: boolean }) {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState<ProductCategory | 'all'>(initialCategory);
  const [brand, setBrand] = useState('all');
  const [power, setPower] = useState('all');
  const [cap, setCap] = useState('all');
  const [priceMin, setPriceMin] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [showOpen, setShowOpen] = useState(false);

  const base = useMemo(() => (lockCategory && initialCategory !== 'all' ? products.filter((p) => p.category === initialCategory) : products), [lockCategory, initialCategory]);
  const brands = useMemo(() => Array.from(new Set(base.map((p) => p.brand))).sort(), [base]);
  const priceActive = priceMin !== '' || priceMax !== '';

  const list = base.filter((p) => {
    if (cat !== 'all' && p.category !== cat) return false;
    if (brand !== 'all' && p.brand !== brand) return false;
    if (!powerRanges.find((r) => r.id === power)!.test(p)) return false;
    if (!capRanges.find((r) => r.id === cap)!.test(p)) return false;
    if (priceActive) {
      const b = computePrice(productPrices[p.id]);
      if (!b) return false;
      if (priceMin && b.total < Number(priceMin)) return false;
      if (priceMax && b.total > Number(priceMax)) return false;
    }
    const s = q.trim().toLowerCase();
    if (s && !`${p.title} ${p.brand} ${p.model ?? ''}`.toLowerCase().includes(s)) return false;
    return true;
  });
  const reset = () => { setQ(''); if (!lockCategory) setCat(initialCategory); setBrand('all'); setPower('all'); setCap('all'); setPriceMin(''); setPriceMax(''); };

  const filters = (
    <div className="flex flex-col gap-5">
      {!lockCategory && (
        <div><label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-muted-foreground" htmlFor="f-cat">Kategorija</label>
          <select id="f-cat" className={sel} value={cat} onChange={(e) => setCat(e.target.value as ProductCategory | 'all')} data-testid="select-filter-category"><option value="all">Visos kategorijos</option>{categories.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}</select></div>
      )}
      <div><label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-muted-foreground" htmlFor="f-brand">Gamintojas</label>
        <select id="f-brand" className={sel} value={brand} onChange={(e) => setBrand(e.target.value)} data-testid="select-filter-brand"><option value="all">Visi gamintojai</option>{brands.map((b) => <option key={b} value={b}>{b}</option>)}</select></div>
      <div><label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-muted-foreground" htmlFor="f-power">Galia</label>
        <select id="f-power" className={sel} value={power} onChange={(e) => setPower(e.target.value)} data-testid="select-filter-power">{powerRanges.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}</select></div>
      <div><label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wider text-muted-foreground" htmlFor="f-cap">Baterijos talpa</label>
        <select id="f-cap" className={sel} value={cap} onChange={(e) => setCap(e.target.value)} data-testid="select-filter-capacity">{capRanges.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}</select></div>
      <fieldset>
        <legend className="mb-1.5 text-[12px] font-bold uppercase tracking-wider text-muted-foreground">Kaina, EUR su PVM</legend>
        <div className="grid grid-cols-2 gap-2">
          <input inputMode="numeric" aria-label="Kaina nuo" placeholder="Nuo" className={sel} value={priceMin} onChange={(e) => setPriceMin(e.target.value.replace(/\D/g, ''))} data-testid="input-price-min" />
          <input inputMode="numeric" aria-label="Kaina iki" placeholder="Iki" className={sel} value={priceMax} onChange={(e) => setPriceMax(e.target.value.replace(/\D/g, ''))} data-testid="input-price-max" />
        </div>
        <p className="mt-1.5 text-[12px] text-muted-foreground">Taikant kainos filtrą rodomi tik produktai su paskelbta kaina.</p>
      </fieldset>
      <button type="button" onClick={reset} className="text-left text-sm font-semibold text-[#F28C00]" data-testid="button-filter-reset">Išvalyti filtrus</button>
    </div>
  );

  return (
    <div>
      <div className="mb-6 flex flex-col gap-3 sm:flex-row">
        <label className="relative flex-1">
          <span className="sr-only">Paieška</span>
          <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ieškoti pagal pavadinimą ar gamintoją" className="w-full rounded-full border border-input bg-white py-3.5 pl-11 pr-4 text-[15px] outline-none focus:border-[#F28C00] focus:ring-4 focus:ring-[#F28C00]/15" data-testid="input-search" />
        </label>
        <button type="button" onClick={() => setShowOpen((v) => !v)} aria-expanded={showOpen} className="inline-flex items-center justify-center gap-2 rounded-full border border-border bg-white px-5 py-3 text-sm font-bold lg:hidden" data-testid="button-toggle-filters"><SlidersHorizontal className="h-4 w-4" /> Filtrai</button>
      </div>
      {!lockCategory && (
        <div className="snap-row -mx-5 mb-8 flex gap-2 overflow-x-auto px-5 sm:mx-0 sm:flex-wrap sm:px-0">
          {[{ id: 'all' as const, label: 'Visi' }, ...categories].map((c) => (
            <button key={c.id} type="button" onClick={() => setCat(c.id)} aria-pressed={cat === c.id} className={`shrink-0 rounded-full px-4 py-2 text-[13px] font-bold uppercase tracking-wider transition ${cat === c.id ? 'bg-[#080808] text-white' : 'border border-border bg-white hover:border-[#F28C00]'}`} data-testid={`chip-category-${c.id}`}>{c.label}</button>
          ))}
        </div>
      )}
      <div className="grid gap-8 lg:grid-cols-[260px_1fr]">
        <aside className={`${showOpen ? 'block' : 'hidden'} rounded-3xl border border-border bg-white p-6 lg:block lg:self-start`} aria-label="Filtrai">
          <div className="mb-4 flex items-center justify-between lg:hidden"><span className="font-bold">Filtrai</span><button type="button" onClick={() => setShowOpen(false)} aria-label="Uždaryti filtrus"><X className="h-5 w-5" /></button></div>
          {filters}
        </aside>
        <div>
          <p className="mb-4 text-sm text-muted-foreground" aria-live="polite" data-testid="text-result-count">Rasta: {list.length}</p>
          {list.length === 0 ? (
            <div className="flex flex-col items-center rounded-3xl border border-dashed border-border bg-white px-6 py-16 text-center">
              <PackageSearch className="h-10 w-10 text-[#F28C00]" strokeWidth={1.5} />
              <p className="mt-4 font-display text-xl font-bold">Pagal pasirinktus filtrus produktų nėra</p>
              <p className="mt-2 max-w-sm text-sm text-muted-foreground">Pakeiskite filtrus arba paklauskite mūsų — dažnai turime sprendimą, kurio dar nėra kataloge.</p>
              <button type="button" onClick={reset} className="mt-5 rounded-full bg-[#080808] px-5 py-2.5 text-sm font-bold text-white">Išvalyti filtrus</button>
            </div>
          ) : (
            <ul className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {list.map((p) => <li key={p.id}><ProductCard p={p} /></li>)}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

export function ProductCard({ p }: { p: Product }) {
  const cat = categories.find((c) => c.id === p.category)?.label;
  return (
    <article className="card-lift flex h-full flex-col overflow-hidden rounded-3xl border border-border bg-white" data-testid={`card-product-${p.id}`}>
      <div className="relative aspect-[4/3] bg-[#F3F0EB]">
        <Image src={p.image} alt={`${p.title} — iliustracija`} fill sizes="(max-width:640px) 100vw, 320px" className="object-cover" loading="lazy" />
        <span className="absolute left-3 top-3 rounded-full bg-white/90 px-3 py-1 text-[11px] font-bold uppercase tracking-wider backdrop-blur">{cat}</span>
      </div>
      <div className="flex flex-1 flex-col p-5">
        <p className="text-[12px] font-bold uppercase tracking-widest text-[#F28C00]">{p.brand}</p>
        <h3 className="mt-1 font-display text-lg font-bold leading-snug">{p.title}</h3>
        <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 text-[13px]">
          <dt className="text-muted-foreground">Modelis</dt><dd className="text-right font-semibold">{p.model ?? <span className="text-muted-foreground">Tikslinamas</span>}</dd>
          <dt className="text-muted-foreground">Galia</dt><dd className="text-right font-semibold">{p.powerKw != null ? (p.powerKw < 1 ? `${p.powerKw * 1000} W` : `${p.powerKw} kW`) : '—'}</dd>
          <dt className="text-muted-foreground">Talpa</dt><dd className="text-right font-semibold">{p.capacityKwh != null ? `${p.capacityKwh.toLocaleString('lt-LT')} kWh` : '—'}</dd>
          <dt className="text-muted-foreground">Prieinamumas</dt><dd className="text-right font-semibold">{availabilityLabels[p.availability]}</dd>
        </dl>
        <div className="mt-auto pt-5"><PriceTag price={productPrices[p.id]} compact /></div>
        <LeadButton variant="dark" className="mt-4 w-full !py-3" title={p.title} prefill={{ solution: p.title, message: `Domina produktas: ${p.title} (${p.brand}).` }} testId={`button-product-enquire-${p.id}`}>Teirautis</LeadButton>
      </div>
    </article>
  );
}
