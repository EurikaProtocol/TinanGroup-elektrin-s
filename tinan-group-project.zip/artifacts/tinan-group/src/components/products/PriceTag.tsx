import { computePrice, formatEur, INDIVIDUAL_OFFER, type PriceInput } from '@/data/pricing';

export function PriceTag({ price, compact = false }: { price?: PriceInput | null; compact?: boolean }) {
  const b = computePrice(price);
  if (!b) {
    return (
      <div data-testid="text-price">
        <p className={`font-display font-extrabold ${compact ? 'text-[19px]' : 'text-3xl'}`}>{INDIVIDUAL_OFFER}</p>
        <p className="mt-1 text-[12.5px] text-muted-foreground">Kaina pateikiama įvertinus objektą</p>
      </div>
    );
  }
  return (
    <div data-testid="text-price">
      <p className={`font-display font-extrabold ${compact ? 'text-[24px]' : 'text-4xl'}`}>{b.from && <span className="mr-1.5 text-[0.6em] font-bold text-muted-foreground">Nuo</span>}{formatEur(b.total)}</p>
      <p className="mt-1 text-[12.5px] text-muted-foreground">NET {formatEur(b.net)} · PVM {formatEur(b.vat)}</p>
    </div>
  );
}
