import Image from 'next/image';
import Link from 'next/link';
import { Check, Star, ArrowRight } from 'lucide-react';
import type { SolarPackage } from '@/data/packages';
import { PriceTag } from '@/components/products/PriceTag';
import { packagePrices } from '@/data/pricing';
import { LeadButton } from '@/components/forms/LeadModal';

export function PackageCard({ p }: { p: SolarPackage }) {
  const featured = !!p.badge;
  return (
    <article className={`card-lift relative flex h-full flex-col rounded-3xl border bg-white p-6 ${featured ? 'border-[#F28C00] shadow-[0_20px_50px_-30px_rgba(242,140,0,.7)]' : 'border-border'}`} data-testid={`card-package-${p.slug}`}>
      {p.badge && (
        <span className="absolute -top-3 left-1/2 inline-flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-full bg-[#F28C00] px-3.5 py-1 text-[10.5px] font-extrabold uppercase tracking-widest text-black">
          <Star className="h-3 w-3 fill-black" /> {p.badge}
        </span>
      )}
      <h3 className="font-display text-[26px] font-extrabold uppercase leading-none">{p.power} <span className="text-[#F28C00]">{p.name}</span></h3>
      <p className="mt-2 min-h-[42px] text-[14px] leading-snug text-muted-foreground">{p.tagline}</p>
      <div className="relative my-5 aspect-[4/3] overflow-hidden rounded-2xl bg-[#F3F0EB]">
        <Image src={p.image} alt={`${p.power} ${p.name} komplekto įrangos iliustracija`} fill sizes="(max-width:768px) 80vw, 280px" className="object-cover" />
      </div>
      <ul className="flex-1 space-y-2">
        {p.components.map((c) => (
          <li key={c} className="flex items-start gap-2.5 text-[13.5px]"><span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-[#FFF3E2]"><Check className="h-3 w-3 text-[#F28C00]" strokeWidth={3} /></span>{c}</li>
        ))}
      </ul>
      <div className="mt-6 border-t border-border pt-5">
        <PriceTag price={packagePrices[p.slug]} compact />
      </div>
      {p.individual ? (
        <LeadButton className="mt-5 w-full" title={`${p.power} ${p.name}`} prefill={{ propertyType: 'verslas', systemSize: p.power, solution: 'Komercinė elektrinė', battery: true }} testId={`button-package-offer-${p.slug}`}>{p.cta}</LeadButton>
      ) : (
        <Link href={`/saules-elektrines/${p.slug}`} className="group mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#F28C00] px-5 py-3.5 text-[12.5px] font-extrabold uppercase tracking-wider text-black transition hover:bg-[#ff9a14]" data-testid={`link-package-${p.slug}`}>
          {p.cta} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
        </Link>
      )}
      {p.individual && <Link href={`/saules-elektrines/${p.slug}`} className="mt-3 text-center text-[13px] font-semibold text-muted-foreground underline-offset-4 hover:underline">Peržiūrėti komplektaciją</Link>}
    </article>
  );
}

export function PackageGrid({ items }: { items: SolarPackage[] }) {
  return (
    <div className="snap-row -mx-5 flex gap-4 overflow-x-auto px-5 pb-4 pt-4 sm:-mx-8 sm:px-8 lg:mx-0 lg:grid lg:grid-cols-5 lg:overflow-visible lg:px-0">
      {items.map((p) => <div key={p.slug} className="w-[82vw] max-w-[320px] shrink-0 lg:w-auto lg:max-w-none"><PackageCard p={p} /></div>)}
    </div>
  );
}
