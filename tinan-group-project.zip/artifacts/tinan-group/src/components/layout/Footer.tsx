import Link from 'next/link';
import Image from 'next/image';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { t } from '@/i18n';
import { company, PLACEHOLDER } from '@/data/company';

export function Footer() {
  const addr = [company.address.street, company.address.city].filter(Boolean).join(', ');
  return (
    <footer className="bg-[#080808] text-white">
      <div className="mx-auto grid max-w-[1440px] gap-12 px-5 py-16 sm:px-8 md:grid-cols-2 lg:grid-cols-[1.3fr_1fr_1fr_1.2fr]">
        <div>
          <Link href="/" className="inline-block rounded-2xl bg-[#FAF8F5] p-3" data-testid="link-footer-logo">
            <Image src={company.logo} alt="TINAN GROUP" width={424} height={240} className="h-auto w-[132px] mix-blend-multiply" />
          </Link>
          <p className="mt-6 max-w-xs text-[15px] leading-relaxed text-white/60">Saulės elektrinės, kaupikliai ir elektros darbai namams, ūkiams ir verslui visoje Lietuvoje.</p>
        </div>
        <nav aria-label="Svetainės skiltys">
          <p className="eyebrow mb-5 text-[#F28C00]">Sprendimai</p>
          <ul className="space-y-2.5">{t.footerNav.map((n) => <li key={n.href}><Link href={n.href} className="text-[15px] text-white/75 hover:text-[#F28C00]" data-testid={`link-footer-${n.href.slice(1)}`}>{n.label}</Link></li>)}</ul>
        </nav>
        <div>
          <p className="eyebrow mb-5 text-[#F28C00]">Teisinė informacija</p>
          <ul className="space-y-2.5">{t.legalNav.map((n) => <li key={n.href}><Link href={n.href} className="text-[15px] text-white/75 hover:text-[#F28C00]">{n.label}</Link></li>)}</ul>
          <p className="eyebrow mb-4 mt-8 text-[#F28C00]">Sekite mus</p>
          <ul className="flex flex-wrap gap-2">
            {company.social.map((s) => (
              <li key={s.id}>{s.url ? <a href={s.url} target="_blank" rel="noopener noreferrer" className="rounded-full border border-white/15 px-3.5 py-1.5 text-[13px] hover:border-[#F28C00]">{s.label}</a> : <span className="rounded-full border border-dashed border-white/15 px-3.5 py-1.5 text-[13px] text-white/40" title="Nuoroda bus pridėta">{s.label}</span>}</li>
            ))}
          </ul>
        </div>
        <div>
          <p className="eyebrow mb-5 text-[#F28C00]">Kontaktai</p>
          <ul className="space-y-3 text-[15px] text-white/75">
            <li className="flex gap-3"><Phone className="mt-0.5 h-4 w-4 shrink-0 text-[#F28C00]" />{company.phone ? <a href={`tel:${company.phone.replace(/\s/g, '')}`}>{company.phone}</a> : <span className="text-white/40">Telefonas: {PLACEHOLDER}</span>}</li>
            <li className="flex gap-3"><Mail className="mt-0.5 h-4 w-4 shrink-0 text-[#F28C00]" />{company.email ? <a href={`mailto:${company.email}`}>{company.email}</a> : <span className="text-white/40">El. paštas: {PLACEHOLDER}</span>}</li>
            <li className="flex gap-3"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#F28C00]" />{addr || <span className="text-white/40">Adresas: {PLACEHOLDER}</span>}</li>
            <li className="flex gap-3"><Clock className="mt-0.5 h-4 w-4 shrink-0 text-[#F28C00]" />{company.workingHours ?? <span className="text-white/40">Darbo laikas: {PLACEHOLDER}</span>}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="mx-auto flex max-w-[1440px] flex-col gap-2 px-5 py-6 text-[13px] text-white/45 sm:flex-row sm:justify-between sm:px-8">
          <span>© {new Date().getFullYear()} {company.legalName ?? company.name}. Visos teisės saugomos.</span>
          <span>Vaizdai svetainėje yra iliustraciniai.</span>
        </div>
      </div>
    </footer>
  );
}
