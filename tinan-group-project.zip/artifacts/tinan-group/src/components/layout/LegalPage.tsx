import { AlertTriangle } from 'lucide-react';
import { PageHero } from './PageHero';

export function LegalPage({ title, path, sections }: { title: string; path: string; sections: { h: string; p: string }[] }) {
  return (
    <>
      <PageHero eyebrow="Teisinė informacija" title={title} image="/images/commercial-roof.webp" crumbs={[{ name: title, path }]} />
      <article className="mx-auto max-w-3xl px-5 py-20 sm:px-8">
        <div className="mb-10 flex items-start gap-3 rounded-2xl border border-[#F28C00]/40 bg-[#FFF3E2] p-5 text-[14.5px]" role="note">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-[#F28C00]" />
          <p><strong>Juodraštis.</strong> Šis dokumentas yra struktūrinis šablonas ir dar nėra galutinis. Prieš publikuojant jį turi peržiūrėti teisininkas ir papildyti įmonės rekvizitais.</p>
        </div>
        <div className="space-y-10">
          {sections.map((s, i) => (
            <section key={s.h}>
              <h2 className="font-display text-xl font-bold"><span className="mr-2 font-mono text-[14px] text-[#F28C00]">{i + 1}.</span>{s.h}</h2>
              <p className="mt-3 text-[16px] leading-relaxed text-foreground/75">{s.p}</p>
            </section>
          ))}
        </div>
      </article>
    </>
  );
}
