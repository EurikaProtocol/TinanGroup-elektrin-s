import Image from 'next/image';
import Link from 'next/link';
import type { ReactNode } from 'react';
import { ChevronRight } from 'lucide-react';
import { JsonLd } from '@/components/JsonLd';
import { breadcrumbSchema } from '@/lib/seo';

export function PageHero({ eyebrow, title, accent, sub, image, crumbs, children }: { eyebrow: string; title: string; accent?: string; sub?: string; image: string; crumbs: { name: string; path: string }[]; children?: ReactNode }) {
  const all = [{ name: 'Pradžia', path: '/' }, ...crumbs];
  return (
    <section className="relative isolate overflow-hidden bg-[#080808] text-white">
      <JsonLd data={breadcrumbSchema(all)} />
      <Image src={image} alt="" fill priority sizes="100vw" className="-z-10 object-cover opacity-70" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-[#080808] via-[#080808]/80 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 -z-10 h-32 bg-gradient-to-t from-[#080808]/70 to-transparent" />
      <div className="mx-auto max-w-[1440px] px-5 pb-20 pt-10 sm:px-8 lg:pb-28 lg:pt-14">
        <nav aria-label="Kelias" className="hero-in mb-12 text-[13px] text-white/55">
          <ol className="flex flex-wrap items-center gap-1.5">
            {all.map((c, i) => (
              <li key={c.path} className="flex items-center gap-1.5">
                {i < all.length - 1 ? <Link href={c.path} className="hover:text-[#F28C00]">{c.name}</Link> : <span aria-current="page" className="text-white/85">{c.name}</span>}
                {i < all.length - 1 && <ChevronRight className="h-3.5 w-3.5" />}
              </li>
            ))}
          </ol>
        </nav>
        <p className="eyebrow hero-in text-white/70" style={{ animationDelay: '80ms' }}>{eyebrow}</p>
        <h1 className="font-display hero-in mt-4 max-w-4xl text-[clamp(2.4rem,6vw,5rem)] font-extrabold uppercase leading-[0.98]" style={{ animationDelay: '160ms' }}>
          {title} {accent && <span className="text-[#F28C00]">{accent}</span>}
        </h1>
        {sub && <p className="hero-in mt-6 max-w-xl text-[17px] leading-relaxed text-white/75" style={{ animationDelay: '240ms' }}>{sub}</p>}
        {children && <div className="hero-in mt-9 flex flex-wrap gap-3" style={{ animationDelay: '320ms' }}>{children}</div>}
      </div>
    </section>
  );
}

export function SectionHead({ eyebrow, title, sub, center = false, dark = false }: { eyebrow?: string; title: ReactNode; sub?: string; center?: boolean; dark?: boolean }) {
  return (
    <div className={`mb-12 max-w-3xl ${center ? 'mx-auto text-center' : ''}`}>
      <span className={`accent-line mb-5 ${center ? 'mx-auto' : ''}`} />
      {eyebrow && <p className={`eyebrow mb-3 ${dark ? 'text-white/55' : 'text-muted-foreground'}`}>{eyebrow}</p>}
      <h2 className="font-display text-[clamp(1.9rem,4vw,3.25rem)] font-extrabold uppercase leading-[1.02]">{title}</h2>
      {sub && <p className={`mt-4 text-[17px] leading-relaxed ${dark ? 'text-white/65' : 'text-muted-foreground'}`}>{sub}</p>}
    </div>
  );
}
