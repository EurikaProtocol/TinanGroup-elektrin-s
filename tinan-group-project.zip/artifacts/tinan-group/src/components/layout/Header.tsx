'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import * as Dialog from '@radix-ui/react-dialog';
import { Menu, X, ArrowRight, Phone, Mail } from 'lucide-react';
import { t } from '@/i18n';
import { company } from '@/data/company';
import { LeadButton, useLeadModal } from '@/components/forms/LeadModal';

export function Logo({ className = '' }: { className?: string }) {
  return (
    <Link href="/" className={`block shrink-0 ${className}`} aria-label="TINAN GROUP — pradžia" data-testid="link-logo">
      <Image src={company.logo} alt="TINAN GROUP — saulės elektrinių montavimas" width={424} height={240} priority className="h-auto w-[104px] mix-blend-multiply sm:w-[118px]" />
    </Link>
  );
}

export function Header() {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { open: openLead } = useLeadModal();
  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    on(); window.addEventListener('scroll', on, { passive: true });
    return () => window.removeEventListener('scroll', on);
  }, []);
  useEffect(() => setOpen(false), [path]);
  const active = (href: string) => (href === '/' ? path === '/' : path?.startsWith(href));

  return (
    <header className={`sticky top-0 z-50 border-b transition-[background-color,border-color,box-shadow] ${scrolled ? 'border-border bg-[#FAF8F5]/92 shadow-[0_8px_30px_-20px_rgba(0,0,0,.35)] backdrop-blur-xl' : 'border-transparent bg-[#FAF8F5]'}`}>
      <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between gap-6 px-5 sm:px-8 lg:h-[84px]">
        <Logo />
        <nav aria-label="Pagrindinė navigacija" className="hidden xl:block">
          <ul className="flex items-center gap-1">
            {t.nav.map((n) => (
              <li key={n.href}>
                <Link href={n.href} aria-current={active(n.href) ? 'page' : undefined} className={`relative rounded-full px-3.5 py-2 text-[14px] font-semibold transition hover:text-[#F28C00] ${active(n.href) ? 'text-[#F28C00]' : 'text-foreground/80'}`} data-testid={`link-nav-${n.href.replace(/\//g, '') || 'home'}`}>
                  {n.label}
                  {active(n.href) && <span className="absolute inset-x-3.5 -bottom-0.5 h-[2px] rounded bg-[#F28C00]" />}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div className="flex items-center gap-2">
          <a href={`tel:${company.phone.replace(/\s/g, '')}`} aria-label={`Skambinti ${company.phone}`} className="hidden h-10 items-center gap-2 rounded-full border border-border px-3 text-sm font-bold hover:border-[#F28C00] lg:inline-flex xl:hidden">
            <Phone className="h-4 w-4 text-[#F28C00]" />{company.phone}
          </a>
          <a href={`tel:${company.phone.replace(/\s/g, '')}`} aria-label="Skambinti Tinan Group" className="grid h-10 w-10 place-items-center rounded-full border border-border hover:border-[#F28C00] xl:hidden lg:hidden">
            <Phone className="h-4 w-4 text-[#F28C00]" />
          </a>
          <LeadButton className="hidden sm:inline-flex" testId="button-header-offer" />
          <Dialog.Root open={open} onOpenChange={setOpen}>
            <Dialog.Trigger className="grid h-11 w-11 place-items-center rounded-full border border-border bg-white xl:hidden" aria-label="Atidaryti meniu" data-testid="button-mobile-menu">
              <Menu className="h-5 w-5" />
            </Dialog.Trigger>
            <Dialog.Portal>
              <Dialog.Overlay className="fixed inset-0 z-[60] bg-black/50 data-[state=open]:animate-in data-[state=open]:fade-in-0" />
              <Dialog.Content className="fixed inset-y-0 right-0 z-[61] flex w-full max-w-[420px] flex-col bg-[#080808] text-white outline-none data-[state=open]:animate-in data-[state=open]:slide-in-from-right" data-testid="panel-mobile-menu">
                <div className="flex h-[72px] items-center justify-between px-6">
                  <Dialog.Title className="eyebrow text-white/50">Meniu</Dialog.Title>
                  <Dialog.Description className="sr-only">Svetainės navigacija</Dialog.Description>
                  <Dialog.Close className="grid h-11 w-11 place-items-center rounded-full border border-white/15" aria-label="Uždaryti meniu" data-testid="button-close-menu"><X className="h-5 w-5" /></Dialog.Close>
                </div>
                <nav aria-label="Mobili navigacija" className="flex-1 overflow-y-auto px-6">
                  <ul className="flex flex-col">
                    {[...t.nav, { href: '/paslaugos', label: 'Paslaugos' }].map((n, i) => (
                      <li key={n.href} className="border-b border-white/8">
                        <Link href={n.href} aria-current={active(n.href) ? 'page' : undefined} className={`flex items-center justify-between py-4 font-display text-[26px] font-bold ${active(n.href) ? 'text-[#F28C00]' : 'text-white'}`} data-testid={`link-mobile-${n.href.replace(/\//g, '') || 'home'}`}>
                          <span><span className="mr-3 align-middle font-mono text-[11px] text-white/35">{String(i + 1).padStart(2, '0')}</span>{n.label}</span>
                          <ArrowRight className="h-5 w-5 text-white/30" />
                        </Link>
                      </li>
                    ))}
                  </ul>
                </nav>
                <div className="space-y-3 border-t border-white/10 p-6">
                  <button type="button" onClick={() => { setOpen(false); openLead(); }} className="flex w-full items-center justify-center gap-2 rounded-full bg-[#F28C00] py-4 text-[14px] font-extrabold uppercase tracking-wider text-black" data-testid="button-mobile-offer">{t.cta.offer} <ArrowRight className="h-4 w-4" /></button>
                  <div className="flex flex-col gap-1 text-sm text-white/60">
                    <a href={`tel:${company.phone.replace(/\s/g, '')}`} className="flex items-center gap-2 hover:text-white"><Phone className="h-4 w-4 text-[#F28C00]" /> {company.phone}</a>
                    <a href={`mailto:${company.email}`} className="flex items-center gap-2 hover:text-white"><Mail className="h-4 w-4 text-[#F28C00]" /> {company.email}</a>
                  </div>
                </div>
              </Dialog.Content>
            </Dialog.Portal>
          </Dialog.Root>
        </div>
      </div>
    </header>
  );
}
