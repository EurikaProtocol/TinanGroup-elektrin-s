'use client';

import { useEffect, useRef, useState, type FormEvent } from 'react';
import { Bot, Check, LoaderCircle, Send, Sun, X } from 'lucide-react';
import { products } from '@/data/products';
import { packages } from '@/data/packages';
import { packagePrices, computePrice, formatEur, INDIVIDUAL_OFFER } from '@/data/pricing';
import { company } from '@/data/company';

const catalogContext = JSON.stringify({
  company: { name: company.name, email: company.email, phone: company.phone, areaServed: company.areaServed },
  products: products.map(({ id, title, brand, model, category, availability, powerKw, capacityKwh, specs }) => ({
    id, title, brand, model, category, availability, powerKw, capacityKwh,
    specs: specs?.filter((spec) => spec.value).map((spec) => `${spec.label}: ${spec.value}`),
    price: INDIVIDUAL_OFFER,
  })),
  packages: packages.map(({ slug, power, name, components }) => ({
    slug, power, name, components,
    price: computePrice(packagePrices[slug]) ? formatEur(computePrice(packagePrices[slug])!.total) : INDIVIDUAL_OFFER,
  })),
});

type ChatMessage = { role: 'user' | 'assistant'; content: string; fallback?: boolean };
type Recommendation = {
  packageSlug: string;
  systemKwp: number | null;
  recommendedKwp: number;
  inverter: string;
  batteryKwh: string | null;
  annualProductionKwh: number | null;
  preliminaryPrice: string;
  savings: string;
  note: string;
};
type LeadForm = {
  name: string; phone: string; email: string; city: string;
  propertyType: 'namas' | 'ukis' | 'verslas'; consumption: string;
  battery: boolean; ev: boolean; heatPump: boolean; consent: boolean;
};

const welcome = 'Sveiki! 👋\n\nEsu Tinan AI – Tinan Group saulės energijos konsultantas.\n\nGaliu padėti pasirinkti saulės elektrinę, kaupiklį ir inverterį pagal jūsų realų elektros suvartojimą.\n\nNuo ko pradėsime?';
const quickActions = ['☀️ Parinkti elektrinę', '🔋 Parinkti kaupiklį', '💰 Apskaičiuoti kainą', '📊 Įvertinti atsipirkimą', '🏠 Įvertinti mano namą', '📄 Gauti pasiūlymą'];
const initialLead: LeadForm = { name: '', phone: '', email: '', city: '', propertyType: 'namas', consumption: '', battery: false, ev: false, heatPump: false, consent: false };

export function TinanAI() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'assistant', content: welcome }]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [showLead, setShowLead] = useState(false);
  const [lead, setLead] = useState(initialLead);
  const [leadState, setLeadState] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);
  const [annualConsumption, setAnnualConsumption] = useState<number | undefined>();
  const [sessionId, setSessionId] = useState('');
  const [error, setError] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let id = sessionStorage.getItem('tinan-ai-session');
    if (!id) {
      id = crypto.randomUUID();
      sessionStorage.setItem('tinan-ai-session', id);
    }
    setSessionId(id);
  }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [messages, open, showLead]);

  async function sendMessage(value: string) {
    const message = value.trim();
    if (!message || busy || !sessionId) return;
    const next = [...messages, { role: 'user' as const, content: message }];
    setMessages(next);
    setText('');
    setBusy(true);
    setError('');
    const match = message.match(/(?:^|\D)(\d{3,6})\s*kwh\b/i);
    if (match) setAnnualConsumption(Number(match[1]));
    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message,
            history: next.slice(-9, -1).map((item) => ({ ...item, content: item.content.slice(0, 500) })),
            catalog: catalogContext,
          context: {
            ...((match ? Number(match[1]) : annualConsumption) ? { annualConsumption: match ? Number(match[1]) : annualConsumption } : {}),
            battery: /kaupikl|baterij|backup|eps/i.test(message) || undefined,
            electricVehicle: /elektromobil|\bEV\b/i.test(message) || undefined,
            heatPump: /šilumos siurbl/i.test(message) || undefined,
          },
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Nepavyko gauti atsakymo.');
      setMessages((current) => [...current, { role: 'assistant', content: data.answer, fallback: data.fallback === true }]);
      setRecommendation(data.recommendation ?? null);
    } catch {
      setError('TINAN AI šiuo metu trumpam nepasiekiamas. Galite pateikti užklausą ir Tinan Group komanda su jumis susisieks.');
    } finally {
      setBusy(false);
    }
  }

  async function submitLead(event: FormEvent) {
    event.preventDefault();
    if (leadState === 'sending') return;
    if (lead.name.trim().length < 2 || lead.phone.replace(/\D/g, '').length < 6 ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(lead.email.trim()) || lead.city.trim().length < 2 || !lead.consent) {
      setLeadState('error');
      return;
    }
    setLeadState('sending');
    const details = [
      'Užklausa pateikta per TINAN AI.',
      `AI pokalbio ID: ${sessionId}`,
      `Elektromobilis: ${lead.ev ? 'taip' : 'ne'}`,
      `Šilumos siurblys: ${lead.heatPump ? 'taip' : 'ne'}`,
      `Preliminari rekomendacija: ${recommendation?.systemKwp ? `${recommendation.systemKwp} kWp` : 'tikslinama'}.`,
      `Kaupiklis: ${lead.battery ? 'domina' : 'nepasirinktas'}.`,
      `Pokalbio santrauka: ${messages.filter((m) => m.role === 'user').slice(-5).map((m) => m.content.slice(0, 450)).join(' | ')}`,
    ].join('\n');
    try {
      const response = await fetch('/api/leads', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: lead.name.trim(), phone: lead.phone.trim(), email: lead.email.trim(),
          city: lead.city.trim(), propertyType: lead.propertyType, consent: true, website: '',
          ...(lead.consumption && { annualConsumption: `${lead.consumption} kWh per metus` }),
          ...(recommendation?.systemKwp && { systemSize: `${recommendation.systemKwp} kWp` }),
          battery: lead.battery,
          solution: 'Užklausa per TINAN AI',
          message: details,
        }),
      });
      if (!response.ok) throw new Error('Lead submission failed');
      setLeadState('success');
    } catch {
      setLeadState('error');
    }
  }

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} aria-label="Atidaryti Tinan AI konsultantą"
        className="fixed bottom-5 right-5 z-[80] inline-flex items-center gap-2 rounded-full bg-[#F28C00] px-5 py-4 font-extrabold text-black shadow-[0_12px_36px_rgba(0,0,0,.28)] transition hover:scale-[1.03] hover:bg-[#ff9a14] focus-visible:outline focus-visible:outline-4 focus-visible:outline-offset-2 focus-visible:outline-[#F28C00]">
        <Sun className="h-5 w-5" /> TINAN AI
      </button>

      {open && <div className="fixed inset-0 z-[90] flex justify-end bg-black/45 sm:items-end sm:bg-transparent sm:p-5" onMouseDown={(event) => { if (event.target === event.currentTarget) setOpen(false); }}>
        <section aria-label="TINAN AI pokalbis" className="flex h-[100dvh] w-full flex-col overflow-hidden bg-white text-[#151515] shadow-2xl sm:h-[min(760px,calc(100dvh-40px))] sm:max-w-[430px] sm:rounded-3xl sm:border sm:border-black/10">
          <header className="flex items-center justify-between bg-[#111] px-5 py-4 text-white">
            <div className="flex items-center gap-3">
              <span className="grid h-11 w-11 place-items-center rounded-full bg-[#F28C00] text-black"><Sun className="h-6 w-6" /></span>
              <div><h2 className="font-display text-lg font-extrabold">TINAN AI</h2><p className="text-xs text-white/70">Saulės energijos konsultantas</p><p className="mt-1 text-[11px] text-[#80d998]">● Online</p></div>
            </div>
            <div className="flex gap-1">
              <button type="button" onClick={() => { setMessages([{ role: 'assistant', content: welcome }]); setRecommendation(null); setAnnualConsumption(undefined); setShowLead(false); setLead(initialLead); setLeadState('idle'); setError(''); }} className="rounded-lg px-2 py-2 text-xs font-semibold text-white/75 hover:bg-white/10">Naujas pokalbis</button>
              <button type="button" onClick={() => setOpen(false)} aria-label="Uždaryti" className="rounded-full p-2 hover:bg-white/10"><X className="h-5 w-5" /></button>
            </div>
          </header>
          <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto bg-[#f7f7f7] p-4">
            {messages.map((item, i) => <div key={`${i}-${item.role}`} className={`flex gap-2 ${item.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              {item.role === 'assistant' && <span className="mt-1 grid h-7 w-7 shrink-0 place-items-center rounded-full bg-[#F28C00] text-black"><Bot className="h-4 w-4" /></span>}
              <div className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed ${item.role === 'user' ? 'rounded-br-md bg-[#F28C00] text-black' : 'rounded-bl-md border border-black/5 bg-white text-[#252525] shadow-sm'}`}>
                {item.fallback && <p role="status" className="mb-2 rounded-lg bg-amber-50 px-2 py-1.5 text-[11px] font-bold text-amber-900">OpenAI kvota / limitas pasiektas · vietinis skaičiuotuvas, ne AI modelis</p>}
                {item.content}
              </div>
            </div>)}
            {recommendation && <div className="rounded-2xl border border-[#F28C00]/50 bg-white p-4 shadow-sm">
              <p className="text-xs font-extrabold uppercase tracking-wider text-[#ad6100]">Jūsų preliminarus sprendimas</p>
              <p className="mt-2 text-2xl font-extrabold">{recommendation.systemKwp ? `${recommendation.systemKwp} kWp` : `${recommendation.recommendedKwp}+ kWp`}</p>
              <p className="mt-1 text-sm">{recommendation.inverter}</p>
              <p className="mt-1 text-sm">Kaupiklis: {recommendation.batteryKwh ? `${recommendation.batteryKwh} kWh (preliminariai)` : 'nepasirinktas'}</p>
              <p className="mt-1 text-sm">Metinė gamyba: {recommendation.annualProductionKwh ? `~${recommendation.annualProductionKwh.toLocaleString('lt-LT')} kWh (preliminariai)` : 'tikslinama individualiai'}</p>
            <p className="mt-1 text-sm">Kaina: {recommendation.preliminaryPrice}</p>
            <p className="mt-1 text-xs text-black/60">{recommendation.savings}</p>
              <p className="mt-2 text-xs leading-relaxed text-black/60">{recommendation.note}</p>
              <button onClick={() => setShowLead(true)} className="mt-3 w-full rounded-full bg-[#F28C00] px-4 py-3 text-xs font-extrabold tracking-wide text-black">GAUTI KONKRETŲ PASIŪLYMĄ</button>
            </div>}
            {error && <div role="alert" className="rounded-2xl border border-orange-200 bg-orange-50 p-4 text-sm text-[#242424]">{error}<button onClick={() => setShowLead(true)} className="mt-2 block font-extrabold text-[#9a5300] underline">GAUTI PASIŪLYMĄ</button></div>}
            {showLead && <div className="rounded-2xl border border-black/10 bg-white p-4 shadow-sm">
              {leadState === 'success' ? <div role="status" className="flex items-center gap-2 py-4 font-semibold"><Check className="text-green-600" /> Užklausa gauta. Tinan Group komanda su jumis susisieks.</div> :
                <form onSubmit={submitLead} className="grid grid-cols-2 gap-2.5">
                  <p className="col-span-2 text-sm font-extrabold">Galiu perduoti jūsų užklausą Tinan Group komandai.</p>
                  <a href={`tel:${company.phone.replace(/\s/g, '')}`} className="col-span-2 inline-flex items-center gap-2 text-xs font-semibold"><Sun className="h-3.5 w-3.5 text-[#F28C00]" />{company.phone} · {company.email}</a>
                  <input aria-label="Vardas" required minLength={2} maxLength={120} autoComplete="name" placeholder="Vardas" value={lead.name} onChange={(e) => setLead({ ...lead, name: e.target.value })} className="rounded-xl border px-3 py-2.5 text-sm" />
                  <input aria-label="Telefonas" required type="tel" autoComplete="tel" placeholder="Telefonas" value={lead.phone} onChange={(e) => setLead({ ...lead, phone: e.target.value })} className="rounded-xl border px-3 py-2.5 text-sm" />
                  <input aria-label="El. paštas" required type="email" autoComplete="email" placeholder="El. paštas" value={lead.email} onChange={(e) => setLead({ ...lead, email: e.target.value })} className="col-span-2 rounded-xl border px-3 py-2.5 text-sm" />
                  <input aria-label="Miestas" required minLength={2} placeholder="Miestas" value={lead.city} onChange={(e) => setLead({ ...lead, city: e.target.value })} className="rounded-xl border px-3 py-2.5 text-sm" />
                  <select aria-label="Objekto tipas" value={lead.propertyType} onChange={(e) => setLead({ ...lead, propertyType: e.target.value as LeadForm['propertyType'] })} className="rounded-xl border px-3 py-2.5 text-sm"><option value="namas">Namas</option><option value="ukis">Ūkis</option><option value="verslas">Verslas</option></select>
                  <input aria-label="Metinis suvartojimas kWh" type="number" min="1" placeholder="Suvartojimas kWh/metus" value={lead.consumption} onChange={(e) => setLead({ ...lead, consumption: e.target.value })} className="col-span-2 rounded-xl border px-3 py-2.5 text-sm" />
                  <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={lead.battery} onChange={(e) => setLead({ ...lead, battery: e.target.checked })} /> Kaupiklis</label>
                  <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={lead.ev} onChange={(e) => setLead({ ...lead, ev: e.target.checked })} /> Elektromobilis</label>
                  <label className="col-span-2 flex items-center gap-2 text-xs"><input type="checkbox" checked={lead.heatPump} onChange={(e) => setLead({ ...lead, heatPump: e.target.checked })} /> Šilumos siurblys</label>
                  <label className="col-span-2 flex items-start gap-2 text-xs leading-relaxed"><input required type="checkbox" checked={lead.consent} onChange={(e) => setLead({ ...lead, consent: e.target.checked })} /><span>Sutinku, kad Tinan Group susisiektų dėl užklausos ir tvarkytų duomenis pagal <a href="/privatumo-politika" target="_blank" rel="noreferrer" className="underline">privatumo politiką</a>.</span></label>
                  {leadState === 'error' && <p role="alert" className="col-span-2 text-xs text-red-700">Patikrinkite laukus arba bandykite dar kartą.</p>}
                  <button disabled={leadState === 'sending'} className="col-span-2 rounded-full bg-[#F28C00] px-4 py-3 text-xs font-extrabold text-black disabled:opacity-60">{leadState === 'sending' ? 'SIUNČIAMA…' : 'SIŲSTI UŽKLAUSĄ'}</button>
                </form>}
            </div>}
            {messages.length === 1 && <div className="flex flex-wrap gap-2 pl-9">{quickActions.map((action) => <button key={action} disabled={busy} onClick={() => action.includes('pasiūlymą') ? setShowLead(true) : sendMessage(action.replace(/^[^\p{L}\p{N}]+/u, ''))} className="rounded-full border border-[#F28C00]/50 bg-white px-3 py-2 text-xs font-semibold transition hover:bg-[#fff2df] disabled:opacity-50">{action}</button>)}</div>}
            {busy && <div className="flex items-center gap-2 pl-9 text-xs text-black/55"><LoaderCircle className="h-4 w-4 animate-spin" /> Rengiamas atsakymas…</div>}
            <div ref={endRef} />
          </div>
          <form onSubmit={(e) => { e.preventDefault(); void sendMessage(text); }} className="flex items-center gap-2 border-t bg-white p-3">
            <input value={text} onChange={(e) => setText(e.target.value)} disabled={busy} maxLength={1200} placeholder="Parašykite klausimą…" aria-label="Žinutė Tinan AI" className="min-w-0 flex-1 rounded-full bg-[#f1f1f1] px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-[#F28C00]" />
            <button type="submit" disabled={busy || !text.trim()} aria-label="Siųsti žinutę" className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-[#F28C00] text-black disabled:opacity-50"><Send className="h-4 w-4" /></button>
          </form>
        </section>
      </div>}
    </>
  );
}
