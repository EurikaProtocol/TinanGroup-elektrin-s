import Image from 'next/image';
import { Trophy, Users, ShieldCheck, Wrench, FileText, SlidersHorizontal, Ruler, Hammer, BatteryCharging, Cpu, Zap, Landmark, Activity, ChevronDown } from 'lucide-react';
import { trustPoints } from '@/data/company';
import { processSteps, type Service, type ServiceIcon } from '@/data/services';
import { Reveal } from '@/components/Reveal';
import { SectionHead } from '@/components/layout/PageHero';
import { LeadButton } from '@/components/forms/LeadModal';

const trustIcons = { trophy: Trophy, users: Users, shield: ShieldCheck, wrench: Wrench, file: FileText, sliders: SlidersHorizontal };
const serviceIcons: Record<ServiceIcon, typeof Trophy> = { ruler: Ruler, hammer: Hammer, battery: BatteryCharging, cpu: Cpu, zap: Zap, file: FileText, landmark: Landmark, activity: Activity, shield: ShieldCheck, wrench: Wrench };

export function TrustSection() {
  return (
    <section className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
      <div className="grid gap-12 lg:grid-cols-[0.8fr_2fr]">
        <SectionHead title={<>Kodėl verta rinktis <span className="text-[#F28C00]">TINAN GROUP?</span></>} />
        <ul className="grid grid-cols-1 gap-px overflow-hidden rounded-3xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {trustPoints.map((tp, i) => {
            const Icon = trustIcons[tp.icon];
            return (
              <Reveal as="li" key={tp.id} delay={i * 60} className="bg-white p-7">
                <Icon className="h-8 w-8 text-[#F28C00]" strokeWidth={1.5} />
                <h3 className="mt-5 font-display text-[19px] font-bold leading-tight">
                  {tp.id === 'experience' ? (tp.value ? `${tp.value} ${tp.title}` : <>Ilgametė patirtis <span className="ml-1 rounded bg-[#FFF3E2] px-1.5 py-0.5 align-middle text-[10px] font-bold uppercase tracking-wider text-[#a35e00]">metai tikslinami</span></>) : tp.title}
                </h3>
                <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">{tp.text}</p>
              </Reveal>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

export function ProcessTimeline({ dark = true }: { dark?: boolean }) {
  return (
    <section className={dark ? 'bg-[#080808] text-white' : ''}>
      <div className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
        <SectionHead dark={dark} eyebrow="Procesas" title={<>Nuo idėjos iki <span className="text-[#F28C00]">veikiančios elektrinės</span></>} />
        <ol className="relative grid gap-0 md:grid-cols-4 md:gap-y-12">
          {processSteps.map((s, i) => (
            <Reveal as="li" key={s.n} delay={(i % 4) * 90} className="relative border-l border-white/15 pb-10 pl-8 md:border-l-0 md:border-t md:pb-0 md:pl-0 md:pr-6 md:pt-8">
              <span className="absolute -left-[7px] top-0 h-3.5 w-3.5 rounded-full border-2 border-[#F28C00] bg-[#080808] md:-top-[7px] md:left-0" />
              <p className="font-mono text-[13px] font-bold text-[#F28C00]">{s.n}</p>
              <h3 className="mt-2 font-display text-[20px] font-bold">{s.title}</h3>
              <p className={`mt-1.5 text-[14px] ${dark ? 'text-white/60' : 'text-muted-foreground'}`}>{s.text}</p>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  );
}

export function ServiceCard({ s, i = 0 }: { s: Service; i?: number }) {
  const Icon = serviceIcons[s.icon];
  return (
    <Reveal delay={(i % 3) * 70} className="card-lift group flex h-full flex-col rounded-3xl border border-border bg-white p-7">
      <div className="flex items-start justify-between">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#FFF3E2]"><Icon className="h-6 w-6 text-[#F28C00]" strokeWidth={1.6} /></span>
        <span className="font-mono text-[12px] text-muted-foreground">{String(i + 1).padStart(2, '0')}</span>
      </div>
      <h3 className="mt-6 font-display text-[20px] font-bold leading-tight">{s.title}</h3>
      <p className="mt-2 flex-1 text-[14.5px] leading-relaxed text-muted-foreground">{s.text}</p>
      <LeadButton variant="light" className="mt-6 self-start !px-4 !py-2.5 !text-[11.5px]" title={s.title} prefill={{ solution: s.title }} testId={`button-service-${s.slug}`}>Užklausti</LeadButton>
    </Reveal>
  );
}

export function FaqList({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="divide-y divide-border rounded-3xl border border-border bg-white">
      {items.map((f, i) => (
        <details key={i} className="group p-6 [&_summary::-webkit-details-marker]:hidden">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-[17px] font-bold">
            {f.q}<ChevronDown className="h-5 w-5 shrink-0 text-[#F28C00] transition group-open:rotate-180" />
          </summary>
          <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">{f.a}</p>
        </details>
      ))}
    </div>
  );
}

export function CtaBand({ title = 'Visas procesas nuo A iki Z', text = 'Projektavimas, įrangos parinkimas, montavimas, dokumentai ir pagalba gaunant paramą. Jūs rūpinatės savo planais — mes energija.' }: { title?: string; text?: string }) {
  return (
    <section className="mx-auto max-w-[1440px] px-5 pb-24 sm:px-8">
      <div className="relative isolate overflow-hidden rounded-[28px] bg-[#080808] px-7 py-14 text-white sm:px-14 sm:py-20">
        <Image src="/images/commercial-roof.webp" alt="" fill sizes="100vw" className="-z-10 object-cover opacity-55" loading="lazy" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-[#080808] via-[#080808]/85 to-[#080808]/20" />
        <p className="eyebrow text-white/60">Saulės energija be rūpesčių</p>
        <h2 className="mt-3 max-w-2xl font-display text-[clamp(2rem,4.5vw,3.6rem)] font-extrabold uppercase leading-[1]">{title}</h2>
        <p className="mt-5 max-w-xl text-[16px] leading-relaxed text-white/70">{text}</p>
        <div className="mt-8 flex flex-wrap gap-3"><LeadButton testId="button-cta-band" /><LeadButton variant="ghost" title="Susisiekti" testId="button-cta-contact">Susisiekti</LeadButton></div>
      </div>
    </section>
  );
}
