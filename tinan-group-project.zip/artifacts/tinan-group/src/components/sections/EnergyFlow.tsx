'use client';
import { useState } from 'react';
import { Sun, Home, BatteryCharging, Moon, ZapOff, ShieldCheck } from 'lucide-react';

const modes = [
  { id: 'day', label: 'Diena', icon: Sun, text: 'Saulė maitina namus, perteklius kraunamas į kaupiklį.', nodes: ['Saulė', 'Namai', 'Kaupiklis'] },
  { id: 'night', label: 'Naktis', icon: Moon, text: 'Sukaupta energija naudojama vakare ir naktį.', nodes: ['Kaupiklis', 'Namai'] },
  { id: 'outage', label: 'Dingus tinklui', icon: ZapOff, text: 'Backup/EPS režimu kaupiklis maitina svarbiausias grandines.', nodes: ['Kaupiklis', 'Backup'] },
] as const;

const iconFor: Record<string, typeof Sun> = { Saulė: Sun, Namai: Home, Kaupiklis: BatteryCharging, Backup: ShieldCheck };

export function EnergyFlow() {
  const [mode, setMode] = useState<(typeof modes)[number]['id']>('day');
  const m = modes.find((x) => x.id === mode)!;
  return (
    <div className="rounded-[28px] bg-[#080808] p-6 text-white sm:p-10">
      <div role="tablist" aria-label="Energijos srauto režimas" className="inline-flex rounded-full border border-white/12 p-1">
        {modes.map((x) => (
          <button key={x.id} role="tab" aria-selected={mode === x.id} onClick={() => setMode(x.id)} className={`inline-flex items-center gap-2 rounded-full px-4 py-2 text-[13px] font-bold transition ${mode === x.id ? 'bg-[#F28C00] text-black' : 'text-white/70 hover:text-white'}`} data-testid={`tab-flow-${x.id}`}>
            <x.icon className="h-4 w-4" /> <span className="hidden sm:inline">{x.label}</span>
          </button>
        ))}
      </div>
      <div key={mode} className="step-in mt-10 flex items-center justify-between gap-2 sm:justify-center sm:gap-0">
        {m.nodes.map((n, i) => {
          const Icon = iconFor[n];
          return (
            <div key={n} className="flex items-center">
              <div className="flex flex-col items-center gap-3">
                <span className="grid h-16 w-16 place-items-center rounded-2xl border border-[#F28C00]/40 bg-[#F28C00]/10 sm:h-24 sm:w-24"><Icon className="h-7 w-7 text-[#F28C00] sm:h-10 sm:w-10" strokeWidth={1.5} /></span>
                <span className="text-[13px] font-bold uppercase tracking-wider">{n}</span>
              </div>
              {i < m.nodes.length - 1 && (
                <svg className="mx-1 mb-8 h-6 w-10 sm:mx-4 sm:w-32" viewBox="0 0 128 24" fill="none" aria-hidden>
                  <line x1="2" y1="12" x2="116" y2="12" stroke="#F28C00" strokeWidth="2.5" strokeLinecap="round" className="flow-line" />
                  <path d="M112 5 L124 12 L112 19" stroke="#F28C00" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              )}
            </div>
          );
        })}
      </div>
      <p className="mt-8 text-center text-[16px] text-white/70">{m.text}</p>
    </div>
  );
}
