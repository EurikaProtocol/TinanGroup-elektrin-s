'use client';
import { useState } from 'react';
import Image from 'next/image';
import { Info } from 'lucide-react';
import { projects, projectFilters, type ProjectCategory } from '@/data/projects';

export function ProjectGallery() {
  const [f, setF] = useState<ProjectCategory | 'all'>('all');
  const list = projects.filter((p) => f === 'all' || p.categories.includes(f));
  return (
    <div>
      <div className="mb-8 flex flex-wrap gap-2" role="group" aria-label="Projektų filtras">
        {[{ id: 'all' as const, label: 'Visi' }, ...projectFilters].map((x) => (
          <button key={x.id} type="button" aria-pressed={f === x.id} onClick={() => setF(x.id)} className={`rounded-full px-5 py-2.5 text-[13px] font-bold uppercase tracking-wider transition ${f === x.id ? 'bg-[#080808] text-white' : 'border border-border bg-white hover:border-[#F28C00]'}`} data-testid={`filter-project-${x.id}`}>{x.label}</button>
        ))}
      </div>
      {list.length === 0 ? (
        <p className="rounded-3xl border border-dashed border-border bg-white p-12 text-center text-muted-foreground">Šioje kategorijoje projektų dar nepaskelbta.</p>
      ) : (
        <ul className="grid gap-6 md:grid-cols-2">
          {list.map((p) => (
            <li key={p.id} className="card-lift overflow-hidden rounded-3xl border border-border bg-white" data-testid={`card-project-${p.id}`}>
              <div className="relative aspect-[16/10]">
                <Image src={p.image} alt={`${p.title} — iliustracija`} fill sizes="(max-width:768px) 100vw, 680px" className="object-cover" loading="lazy" />
                {p.illustrative && <span className="absolute left-4 top-4 inline-flex items-center gap-1.5 rounded-full bg-[#080808]/80 px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-white backdrop-blur"><Info className="h-3.5 w-3.5 text-[#F28C00]" /> Pavyzdinė konfigūracija</span>}
              </div>
              <div className="p-6">
                <h3 className="font-display text-xl font-bold">{p.title}</h3>
                <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2 text-[14px] sm:grid-cols-3">
                  {[['Galia', p.systemSize], ['Vieta', p.location ?? 'Nenurodyta'], ['Moduliai', p.panelCount], ['Inverteris', p.inverter], ['Kaupiklis', p.battery ?? '—'], ['Montavimas', p.installationType]].map(([k, v]) => (
                    <div key={k}><dt className="text-[11.5px] font-bold uppercase tracking-wider text-muted-foreground">{k}</dt><dd className="font-semibold">{v}</dd></div>
                  ))}
                </dl>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
