'use client';
import { createContext, useCallback, useContext, useState, type ReactNode } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { X, ArrowRight } from 'lucide-react';
import { LeadForm, type LeadPrefill } from './LeadForm';
import { t } from '@/i18n';

type Ctx = { open: (opts?: { title?: string; prefill?: LeadPrefill }) => void };
const LeadCtx = createContext<Ctx>({ open: () => {} });
export const useLeadModal = () => useContext(LeadCtx);

export function LeadModalProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<{ open: boolean; title?: string; prefill?: LeadPrefill; key: number }>({ open: false, key: 0 });
  const open = useCallback<Ctx['open']>((opts) => setState((s) => ({ open: true, title: opts?.title, prefill: opts?.prefill, key: s.key + 1 })), []);
  const close = () => setState((s) => ({ ...s, open: false }));
  return (
    <LeadCtx.Provider value={{ open }}>
      {children}
      <Dialog.Root open={state.open} onOpenChange={(o) => (o ? null : close())}>
        <Dialog.Portal>
          <Dialog.Overlay className="fixed inset-0 z-[70] bg-black/60 backdrop-blur-sm data-[state=open]:animate-in data-[state=open]:fade-in-0" />
          <Dialog.Content className="fixed inset-x-0 bottom-0 z-[71] max-h-[92dvh] overflow-y-auto rounded-t-3xl bg-[#FAF8F5] p-6 shadow-2xl outline-none data-[state=open]:animate-in data-[state=open]:slide-in-from-bottom-6 sm:inset-auto sm:left-1/2 sm:top-1/2 sm:w-[min(680px,94vw)] sm:-translate-x-1/2 sm:-translate-y-1/2 sm:rounded-3xl sm:p-9" data-testid="modal-lead">
            <div className="mb-6 flex items-start justify-between gap-4">
              <div>
                <span className="accent-line mb-3" />
                <Dialog.Title className="font-display text-2xl font-extrabold uppercase sm:text-3xl">{state.title ?? t.cta.offer}</Dialog.Title>
                <Dialog.Description className="mt-1.5 text-sm text-muted-foreground">Užpildykite formą — specialistas susisieks ir pateiks pasiūlymą.</Dialog.Description>
              </div>
              <Dialog.Close className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-border hover:border-[#F28C00]" aria-label="Uždaryti" data-testid="button-modal-close"><X className="h-5 w-5" /></Dialog.Close>
            </div>
            <LeadForm key={state.key} prefill={state.prefill} idPrefix={`m${state.key}`} variant="modal" onDone={close} />
          </Dialog.Content>
        </Dialog.Portal>
      </Dialog.Root>
    </LeadCtx.Provider>
  );
}

export function LeadButton({ children, title, prefill, variant = 'primary', className = '', testId = 'button-open-lead' }: { children?: ReactNode; title?: string; prefill?: LeadPrefill; variant?: 'primary' | 'dark' | 'ghost' | 'light'; className?: string; testId?: string }) {
  const { open } = useLeadModal();
  const styles = {
    primary: 'bg-[#F28C00] text-black hover:bg-[#ff9a14]',
    dark: 'bg-[#080808] text-white hover:bg-[#1d1d1d]',
    ghost: 'border border-white/35 text-white hover:border-[#F28C00] hover:text-[#F28C00]',
    light: 'border border-border bg-white text-foreground hover:border-[#F28C00]',
  }[variant];
  return (
    <button type="button" onClick={() => open({ title, prefill })} className={`group inline-flex items-center justify-center gap-2 rounded-full px-6 py-3.5 text-[13px] font-extrabold uppercase tracking-wider transition ${styles} ${className}`} data-testid={testId}>
      {children ?? t.cta.offer} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
    </button>
  );
}
