'use client';
import { useState, type FormEvent } from 'react';
import Link from 'next/link';
import { ArrowRight, Check, AlertTriangle, Loader2 } from 'lucide-react';
import { useCreateLead, type LeadInput, type LeadInputPropertyType } from '@workspace/api-client-react';
import { t } from '@/i18n';
import { consumptionBands } from '@/data/calculator';

export type LeadPrefill = Partial<Pick<LeadInput, 'propertyType' | 'annualConsumption' | 'systemSize' | 'solution' | 'battery' | 'message'>>;

type State = {
  name: string; phone: string; email: string; city: string;
  propertyType: LeadInputPropertyType; annualConsumption: string; systemSize: string; solution: string;
  battery: 'taip' | 'ne' | ''; message: string; consent: boolean; website: string;
};

const solutions = ['Saulės elektrinė', 'Hibridinė sistema su kaupikliu', 'Energijos kaupiklis', 'Inverteris', 'Komercinė elektrinė', 'EV įkrovimas', 'Elektros darbai', 'Projektavimas ir dokumentai'];

const inputCls = 'w-full rounded-xl border border-input bg-white px-4 py-3 text-[15px] text-foreground placeholder:text-muted-foreground/70 outline-none transition focus:border-[#F28C00] focus:ring-4 focus:ring-[#F28C00]/15 aria-[invalid=true]:border-destructive';

function Field({ id, label, error, children, required }: { id: string; label: string; error?: string; children: React.ReactNode; required?: boolean }) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-[13px] font-semibold text-foreground/80">{label}{required && <span className="text-brand"> *</span>}</label>
      {children}
      {error && <p id={`${id}-err`} className="text-[12.5px] font-medium text-destructive">{error}</p>}
    </div>
  );
}

export function LeadForm({ prefill, idPrefix = 'lead', variant = 'full', onDone }: { prefill?: LeadPrefill; idPrefix?: string; variant?: 'full' | 'modal'; onDone?: () => void }) {
  const [s, setS] = useState<State>({
    name: '', phone: '', email: '', city: '',
    propertyType: prefill?.propertyType ?? 'namas',
    annualConsumption: prefill?.annualConsumption ?? '', systemSize: prefill?.systemSize ?? '', solution: prefill?.solution ?? '',
    battery: prefill?.battery === undefined ? '' : prefill.battery ? 'taip' : 'ne',
    message: prefill?.message ?? '', consent: false, website: '',
  });
  const [errors, setErrors] = useState<Partial<Record<keyof State, string>>>({});
  const lead = useCreateLead();
  const set = <K extends keyof State>(k: K, v: State[K]) => setS((p) => ({ ...p, [k]: v }));
  const id = (k: string) => `${idPrefix}-${k}`;

  const validate = () => {
    const e: Partial<Record<keyof State, string>> = {};
    if (s.name.trim().length < 2) e.name = 'Įveskite vardą';
    if (s.phone.replace(/\s/g, '').length < 6) e.phone = 'Įveskite telefono numerį';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s.email.trim())) e.email = 'Įveskite teisingą el. pašto adresą';
    if (s.city.trim().length < 2) e.city = 'Įveskite miestą';
    if (!s.consent) e.consent = 'Būtinas sutikimas';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev: FormEvent) => {
    ev.preventDefault();
    if (lead.isPending || !validate()) return;
    const data: LeadInput = {
      name: s.name.trim(), phone: s.phone.trim(), email: s.email.trim(), city: s.city.trim(),
      propertyType: s.propertyType, consent: true, website: s.website,
      ...(s.annualConsumption && { annualConsumption: s.annualConsumption }),
      ...(s.systemSize.trim() && { systemSize: s.systemSize.trim() }),
      ...(s.solution && { solution: s.solution }),
      ...(s.battery && { battery: s.battery === 'taip' }),
      ...(s.message.trim() && { message: s.message.trim() }),
    };
    lead.mutate({ data });
  };

  if (lead.isSuccess) {
    return (
      <div role="status" aria-live="polite" className="step-in flex flex-col items-start gap-4 py-6" data-testid="status-lead-success">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-[#F28C00] text-black"><Check className="h-7 w-7" strokeWidth={2.5} /></span>
        <h3 className="font-display text-4xl font-extrabold uppercase">{t.form.successTitle}</h3>
        <p className="max-w-md text-[16px] leading-relaxed text-muted-foreground">{t.form.successText}</p>
        {lead.data?.id && <p className="text-xs text-muted-foreground">Užklausos nr.: <span className="font-mono">{lead.data.id}</span></p>}
        {onDone && <button type="button" onClick={onDone} className="mt-2 rounded-full border border-border px-5 py-2.5 text-sm font-semibold hover:border-[#F28C00]" data-testid="button-lead-close">Uždaryti</button>}
      </div>
    );
  }

  const status = (lead.error as { status?: number } | null)?.status;
  const errorText = status === 429 ? 'Per daug užklausų per trumpą laiką. Pabandykite po kelių minučių.' : status === 400 ? 'Patikrinkite laukus ir bandykite dar kartą.' : t.form.error;
  const grid = variant === 'full' ? 'sm:grid-cols-2' : 'sm:grid-cols-2';

  return (
    <form onSubmit={submit} noValidate className="flex flex-col gap-4" data-testid="form-lead">
      <div className={`grid grid-cols-1 gap-4 ${grid}`}>
        <Field id={id('name')} label={t.form.name} error={errors.name} required>
          <input id={id('name')} className={inputCls} autoComplete="name" value={s.name} onChange={(e) => set('name', e.target.value)} aria-invalid={!!errors.name} maxLength={120} data-testid="input-name" />
        </Field>
        <Field id={id('phone')} label={t.form.phone} error={errors.phone} required>
          <input id={id('phone')} type="tel" className={inputCls} autoComplete="tel" placeholder="+370" value={s.phone} onChange={(e) => set('phone', e.target.value)} aria-invalid={!!errors.phone} maxLength={32} data-testid="input-phone" />
        </Field>
        <Field id={id('email')} label={t.form.email} error={errors.email} required>
          <input id={id('email')} type="email" className={inputCls} autoComplete="email" value={s.email} onChange={(e) => set('email', e.target.value)} aria-invalid={!!errors.email} maxLength={254} data-testid="input-email" />
        </Field>
        <Field id={id('city')} label={t.form.city} error={errors.city} required>
          <input id={id('city')} className={inputCls} autoComplete="address-level2" value={s.city} onChange={(e) => set('city', e.target.value)} aria-invalid={!!errors.city} maxLength={120} data-testid="input-city" />
        </Field>
        <Field id={id('property')} label={t.form.property} required>
          <select id={id('property')} className={inputCls} value={s.propertyType} onChange={(e) => set('propertyType', e.target.value as LeadInputPropertyType)} data-testid="select-property">
            {(Object.keys(t.property) as LeadInputPropertyType[]).map((k) => <option key={k} value={k}>{t.property[k]}</option>)}
          </select>
        </Field>
        <Field id={id('consumption')} label={t.form.consumption}>
          <select id={id('consumption')} className={inputCls} value={s.annualConsumption} onChange={(e) => set('annualConsumption', e.target.value)} data-testid="select-consumption">
            <option value="">Nežinau / nenurodysiu</option>
            {consumptionBands.map((b) => <option key={b.id} value={b.label}>{b.label}</option>)}
          </select>
        </Field>
        <Field id={id('size')} label={t.form.size}>
          <input id={id('size')} className={inputCls} placeholder="pvz. 10 kW" value={s.systemSize} onChange={(e) => set('systemSize', e.target.value)} maxLength={120} data-testid="input-size" />
        </Field>
        <Field id={id('solution')} label={t.form.solution}>
          <select id={id('solution')} className={inputCls} value={s.solution} onChange={(e) => set('solution', e.target.value)} data-testid="select-solution">
            <option value="">Pasirinkite</option>
            {s.solution && !solutions.includes(s.solution) && <option value={s.solution}>{s.solution}</option>}
            {solutions.map((o) => <option key={o} value={o}>{o}</option>)}
          </select>
        </Field>
      </div>

      <fieldset className="flex flex-col gap-2">
        <legend className="mb-1.5 text-[13px] font-semibold text-foreground/80">{t.form.battery}</legend>
        <div className="grid grid-cols-3 gap-2">
          {([['taip', 'Taip'], ['ne', 'Ne'], ['', 'Dar nežinau']] as const).map(([v, l]) => (
            <label key={l} className={`cursor-pointer rounded-xl border px-3 py-2.5 text-center text-sm font-semibold transition ${s.battery === v ? 'border-[#F28C00] bg-[#FFF3E2] text-black' : 'border-input bg-white hover:border-[#F28C00]/60'}`}>
              <input type="radio" name={id('battery')} className="sr-only" checked={s.battery === v} onChange={() => set('battery', v)} data-testid={`radio-battery-${v || 'unknown'}`} />{l}
            </label>
          ))}
        </div>
      </fieldset>

      <Field id={id('message')} label={t.form.message}>
        <textarea id={id('message')} rows={variant === 'full' ? 4 : 3} className={inputCls} value={s.message} onChange={(e) => set('message', e.target.value)} maxLength={4000} data-testid="input-message" />
      </Field>

      <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
        <label htmlFor={id('website')}>Svetainė</label>
        <input id={id('website')} tabIndex={-1} autoComplete="off" value={s.website} onChange={(e) => set('website', e.target.value)} />
      </div>

      <div>
        <label className="flex cursor-pointer items-start gap-3 text-[13.5px] leading-snug text-muted-foreground">
          <input type="checkbox" checked={s.consent} onChange={(e) => set('consent', e.target.checked)} className="mt-0.5 h-5 w-5 shrink-0 accent-[#F28C00]" aria-invalid={!!errors.consent} data-testid="checkbox-consent" />
          <span>{t.form.consent} <Link href="/privatumo-politika" className="font-semibold text-foreground underline decoration-[#F28C00] underline-offset-4" target="_blank">{t.form.privacy}</Link>.</span>
        </label>
        {errors.consent && <p className="mt-1 text-[12.5px] font-medium text-destructive">{errors.consent}</p>}
      </div>

      {lead.isError && (
        <div role="alert" className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm text-destructive" data-testid="status-lead-error">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{errorText}</span>
        </div>
      )}

      <button type="submit" disabled={lead.isPending} className="group mt-1 inline-flex items-center justify-center gap-2 rounded-full bg-[#F28C00] px-7 py-4 text-[14px] font-extrabold uppercase tracking-wider text-black transition hover:bg-[#ff9a14] disabled:opacity-70" data-testid="button-submit-lead">
        {lead.isPending ? <><Loader2 className="h-4 w-4 animate-spin" /> {t.form.sending}</> : <>{lead.isError ? t.form.retry : t.form.submit} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" /></>}
      </button>
    </form>
  );
}
