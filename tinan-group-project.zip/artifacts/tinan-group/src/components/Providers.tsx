'use client';
import { useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { LeadModalProvider } from '@/components/forms/LeadModal';

export function Providers({ children }: { children: ReactNode }) {
  const [client] = useState(() => new QueryClient());
  return (
    <QueryClientProvider client={client}>
      <LeadModalProvider>{children}</LeadModalProvider>
    </QueryClientProvider>
  );
}
