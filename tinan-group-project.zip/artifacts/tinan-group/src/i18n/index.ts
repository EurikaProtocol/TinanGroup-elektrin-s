import { lt } from './lt';

/**
 * Locale architecture. LT is the default and only active locale.
 * To add English: create ./en.ts satisfying `Dictionary`, add it below,
 * and move routes under app/[locale] (content data modules accept the same shape).
 */
export type Dictionary = typeof lt;
export const locales = ['lt'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'lt';

const dictionaries: Record<Locale, Dictionary> = { lt };
export const getDictionary = (locale: Locale = defaultLocale) => dictionaries[locale];
export const t = dictionaries[defaultLocale];
