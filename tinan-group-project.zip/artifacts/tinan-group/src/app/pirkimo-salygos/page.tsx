import { LegalPage } from '@/components/layout/LegalPage';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Pirkimo sąlygos | Tinan Group', description: 'TINAN GROUP pirkimo sąlygos (juodraštis).', path: '/pirkimo-salygos', noindex: true });

export default function Page() {
  return (
    <LegalPage title="Pirkimo sąlygos" path="/pirkimo-salygos" sections={[
      { h: 'Bendrosios nuostatos', p: 'Svetainėje pateikta informacija nėra vieša oferta. Galutinės sąlygos nustatomos individualiame pasiūlyme ir sutartyje.' },
      { h: 'Kainos', p: 'Kainos nurodomos su PVM. Kur kaina nepaskelbta, pateikiamas individualus pasiūlymas.' },
      { h: 'Montavimas ir terminai', p: 'Montavimo terminai suderinami individualiai pagal objektą ir įrangos prieinamumą.' },
      { h: 'Garantijos', p: 'Įrangos garantijos teikiamos pagal gamintojų sąlygas; montavimo darbų garantija bus nurodyta sutartyje.' },
    ]} />
  );
}
