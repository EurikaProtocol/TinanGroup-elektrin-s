import { PageHero } from '@/components/layout/PageHero';
import { ProductCatalog } from '@/components/products/ProductCatalog';
import { CtaBand } from '@/components/sections/Blocks';
import { pageMeta } from '@/lib/seo';
import { pricingConfig } from '@/data/pricing';

export const metadata = pageMeta({ title: 'Kainoraštis | Tinan Group', description: 'Saulės moduliai, inverteriai, kaupikliai, konstrukcijos, elektros apsaugos ir EV įkrovimo stotelės. Filtrai pagal kategoriją, gamintoją, galią, talpą ir kainą.', path: '/kainorastis' });

export default function Page() {
  return (
    <>
      <PageHero eyebrow="Kainoraštis" title="Įranga, kurią" accent="montuojame" sub={`Kainos nurodomos su ${Math.round(pricingConfig.vatRate * 100)} % PVM. Kur kaina nepaskelbta — pateiksime individualų pasiūlymą.`} image="/images/equipment-ongrid.webp" crumbs={[{ name: 'Kainoraštis', path: '/kainorastis' }]} />
      <section className="mx-auto max-w-[1440px] px-5 py-20 sm:px-8"><ProductCatalog /></section>
      <CtaBand title="Reikia viso komplekto?" text="Sudėsime suderintą sistemą su montavimu ir dokumentais vienoje sąmatoje." />
    </>
  );
}
