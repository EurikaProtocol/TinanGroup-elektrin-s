import Image from 'next/image';
import { PageHero, SectionHead } from '@/components/layout/PageHero';
import { TrustSection, CtaBand } from '@/components/sections/Blocks';
import { Reveal } from '@/components/Reveal';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Apie mus | Tinan Group', description: 'TINAN GROUP — saulės energija, elektros inžinerija ir profesionalus montavimas. Ilgalaikiai santykiai ir energetinė nepriklausomybė.', path: '/apie-mus', image: '/images/installation.webp' });

const pillars = [
  { t: 'Saulės energija', d: 'Projektuojame sistemas, kurios gamina tiek, kiek realiai reikia.' },
  { t: 'Elektros inžinerija', d: 'Saulės elektrinė yra elektros įrenginys — todėl pradedame nuo skydo ir įvado.' },
  { t: 'Profesionalus montavimas', d: 'Tvarkingi kabelių keliai, teisingos apsaugos, švari darbo vieta.' },
  { t: 'Technologijos', d: 'Hibridiniai inverteriai, kaupikliai, monitoringas ir energijos valdymas.' },
  { t: 'Ilgalaikiai santykiai', d: 'Sistema veikia dešimtmečius — mes norime būti šalia visą tą laiką.' },
  { t: 'Energetinė nepriklausomybė', d: 'Mažesnė priklausomybė nuo kainų svyravimų ir tinklo sutrikimų.' },
];

const gallery = [
  { src: '/images/installation.webp', alt: 'Montavimo darbai ant stogo (iliustracija)' },
  { src: '/images/farm.webp', alt: 'Saulės moduliai ant ūkio pastato (iliustracija)' },
  { src: '/images/battery-garage.webp', alt: 'Kaupiklis ir EV įkrovimas garaže (iliustracija)' },
  { src: '/images/commercial-roof.webp', alt: 'Komercinis stogas su moduliais (iliustracija)' },
];

export default function Page() {
  return (
    <>
      <PageHero eyebrow="Apie mus" title="Inžinerija, kuria" accent="galima pasitikėti" sub="TINAN GROUP padeda namų ūkiams ir verslui pasirinkti patikimą energetinę nepriklausomybę." image="/images/installation.webp" crumbs={[{ name: 'Apie mus', path: '/apie-mus' }]} />
      <section className="mx-auto grid max-w-[1440px] gap-12 px-5 py-24 sm:px-8 lg:grid-cols-2">
        <Reveal>
          <SectionHead eyebrow="Mūsų istorija" title={<>Energija, kurią <span className="text-[#F28C00]">pasigaminate patys</span></>} />
          <div className="space-y-5 text-[17px] leading-relaxed text-foreground/80">
            <p>TINAN GROUP — saulės elektrinių montavimo ir elektros darbų komanda. Mums svarbiausia ne parduoti didžiausią sistemą, o parinkti tą, kuri atsipirks ir patikimai veiks.</p>
            <p>Kiekvieną projektą pradedame nuo pokalbio ir objekto įvertinimo, o baigiame paleidimu, dokumentais ir aptarnavimu. Klientas visada žino, kas ir kodėl montuojama.</p>
            <p className="rounded-2xl border border-dashed border-[#F28C00]/50 bg-[#FFF3E2] p-4 text-[14px] text-foreground/70">Įmonės istorijos detalės (įkūrimo metai, komanda, sertifikatai) bus papildytos patvirtinus duomenis.</p>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 gap-4">
          {gallery.map((g, i) => (
            <div key={g.src} className={`relative overflow-hidden rounded-3xl ${i % 3 === 0 ? 'aspect-[3/4]' : 'aspect-square'} ${i === 1 ? 'mt-10' : ''}`}>
              <Image src={g.src} alt={g.alt} fill sizes="(max-width:1024px) 50vw, 340px" className="object-cover" loading="lazy" />
            </div>
          ))}
        </div>
      </section>
      <section className="bg-[#080808] text-white">
        <div className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
          <SectionHead dark title={<>Kuo <span className="text-[#F28C00]">remiamės</span></>} />
          <ul className="grid gap-px overflow-hidden rounded-3xl bg-white/10 sm:grid-cols-2 lg:grid-cols-3">
            {pillars.map((p, i) => (
              <Reveal as="li" key={p.t} delay={i * 60} className="bg-[#111] p-8">
                <p className="font-mono text-[12px] text-[#F28C00]">{String(i + 1).padStart(2, '0')}</p>
                <h3 className="mt-3 font-display text-xl font-bold">{p.t}</h3>
                <p className="mt-2 text-[14.5px] text-white/60">{p.d}</p>
              </Reveal>
            ))}
          </ul>
        </div>
      </section>
      <TrustSection />
      <CtaBand />
    </>
  );
}
