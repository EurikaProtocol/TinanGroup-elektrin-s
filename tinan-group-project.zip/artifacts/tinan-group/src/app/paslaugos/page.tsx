import { PageHero } from '@/components/layout/PageHero';
import { ServiceCard, ProcessTimeline, CtaBand } from '@/components/sections/Blocks';
import { services } from '@/data/services';
import { JsonLd } from '@/components/JsonLd';
import { pageMeta, serviceSchema } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Saulės elektrinių montavimas ir paslaugos | Tinan Group', description: 'Projektavimas, montavimas, kaupiklių ir inverterių montavimas, elektros darbai, ESO ir APVA dokumentacija, monitoringas ir aptarnavimas.', path: '/paslaugos', image: '/images/installation.webp' });

export default function Page() {
  return (
    <>
      <JsonLd data={services.map((s) => serviceSchema(s.title, s.text))} />
      <PageHero eyebrow="Paslaugos" title="Nuo projekto" accent="iki aptarnavimo" sub="Viena komanda atsakinga už visą sistemos gyvavimo ciklą." image="/images/installation.webp" crumbs={[{ name: 'Paslaugos', path: '/paslaugos' }]} />
      <section className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">{services.map((s, i) => <ServiceCard key={s.slug} s={s} i={i} />)}</div>
      </section>
      <ProcessTimeline />
      <div className="pt-24"><CtaBand /></div>
    </>
  );
}
