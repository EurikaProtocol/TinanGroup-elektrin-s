import { PageHero, SectionHead } from '@/components/layout/PageHero';
import { ProductCatalog } from '@/components/products/ProductCatalog';
import { CtaBand } from '@/components/sections/Blocks';
import { LeadButton } from '@/components/forms/LeadModal';
import { Reveal } from '@/components/Reveal';
import { inverterTypeLabels, products, type InverterType } from '@/data/products';
import { JsonLd } from '@/components/JsonLd';
import { pageMeta, serviceSchema } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Inverteriai | Tinan Group', description: 'Hibridiniai, tinkliniai ir komerciniai inverteriai, žemos ir aukštos įtampos baterijų sistemoms. Parinkimas ir montavimas.', path: '/inverteriai', image: '/images/equipment-hybrid.webp' });

export default function Page() {
  const types = Object.keys(inverterTypeLabels) as InverterType[];
  return (
    <>
      <JsonLd data={serviceSchema('Inverterių montavimas', 'Tinklinių, hibridinių ir komercinių inverterių parinkimas ir montavimas.')} />
      <PageHero eyebrow="Inverteriai" title="Sistemos širdis," accent="parinkta tiksliai" sub="Inverteris lemia efektyvumą, plėtros galimybes ir suderinamumą su kaupikliu." image="/images/equipment-hybrid.webp" crumbs={[{ name: 'Inverteriai', path: '/inverteriai' }]}>
        <LeadButton title="Inverterio pasiūlymas" prefill={{ solution: 'Inverteris' }} testId="button-inverter-hero" />
      </PageHero>
      <section className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
        <SectionHead title={<>Inverterių <span className="text-[#F28C00]">kategorijos</span></>} />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
          {types.map((k, i) => {
            const count = products.filter((p) => p.inverterTypes?.includes(k)).length;
            return (
              <Reveal key={k} delay={i * 60} className="rounded-3xl border border-border bg-white p-6">
                <p className="font-mono text-[12px] text-[#F28C00]">{String(i + 1).padStart(2, '0')}</p>
                <h3 className="mt-3 font-display text-[19px] font-bold leading-tight">{inverterTypeLabels[k].label}</h3>
                <p className="mt-2 text-[14px] leading-relaxed text-muted-foreground">{inverterTypeLabels[k].text}</p>
                <p className="mt-4 text-[12px] font-bold uppercase tracking-wider text-muted-foreground">Kataloge: {count}</p>
              </Reveal>
            );
          })}
        </div>
        <div className="mt-10 overflow-x-auto rounded-3xl border border-border bg-white">
          <table className="w-full min-w-[640px] text-left text-[14px]">
            <caption className="p-5 text-left font-display text-lg font-bold">Techninės specifikacijos <span className="ml-2 text-[12px] font-semibold text-muted-foreground">(pildoma pagal gamintojų duomenų lapus)</span></caption>
            <thead className="bg-[#F5F3EF] text-[12px] uppercase tracking-wider text-muted-foreground"><tr><th className="p-4">Produktas</th><th className="p-4">Gamintojas</th><th className="p-4">Galia</th><th className="p-4">Tipas</th><th className="p-4">Specifikacijos</th></tr></thead>
            <tbody className="divide-y divide-border">
              {products.filter((p) => p.category === 'inverteriai').map((p) => (
                <tr key={p.id}>
                  <td className="p-4 font-semibold">{p.title}</td><td className="p-4">{p.brand}</td><td className="p-4">{p.powerKw} kW</td>
                  <td className="p-4">{p.inverterTypes?.map((x) => inverterTypeLabels[x].label).join(', ')}</td>
                  <td className="p-4 text-muted-foreground">{p.specs?.map((s) => `${s.label}: ${s.value ?? 'tikslinama'}`).join(' · ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="mx-auto max-w-[1440px] px-5 pb-24 sm:px-8">
        <SectionHead title={<>Inverterių <span className="text-[#F28C00]">katalogas</span></>} />
        <ProductCatalog initialCategory="inverteriai" lockCategory />
      </section>
      <CtaBand title="Nežinote, kurio inverterio reikia?" text="Įvertinsime jūsų elektros įvadą, planus ir kaupiklio poreikį — ir pasiūlysime tinkamą sprendimą." />
    </>
  );
}
