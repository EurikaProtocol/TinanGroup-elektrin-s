import { LegalPage } from '@/components/layout/LegalPage';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Privatumo politika | Tinan Group', description: 'TINAN GROUP privatumo politika (juodraštis).', path: '/privatumo-politika', noindex: true });

export default function Page() {
  return (
    <LegalPage title="Privatumo politika" path="/privatumo-politika" sections={[
      { h: 'Duomenų valdytojas', p: 'Duomenų valdytojo pavadinimas, įmonės kodas ir kontaktai bus nurodyti patvirtinus įmonės rekvizitus.' },
      { h: 'Kokius duomenis renkame', p: 'Užklausos formoje pateiktus duomenis: vardą, telefono numerį, el. pašto adresą, miestą, objekto tipą, suvartojimo informaciją ir žinutės turinį.' },
      { h: 'Tvarkymo tikslas ir pagrindas', p: 'Duomenys tvarkomi siekiant atsakyti į jūsų užklausą ir pateikti pasiūlymą, remiantis jūsų sutikimu.' },
      { h: 'Saugojimo terminas', p: 'Saugojimo terminas bus nustatytas ir nurodytas galutinėje dokumento versijoje.' },
      { h: 'Jūsų teisės', p: 'Turite teisę susipažinti su savo duomenimis, juos ištaisyti, ištrinti, apriboti tvarkymą ir atšaukti sutikimą, taip pat pateikti skundą Valstybinei duomenų apsaugos inspekcijai.' },
    ]} />
  );
}
