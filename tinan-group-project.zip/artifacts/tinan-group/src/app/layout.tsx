import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import { Sora, Manrope } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/Providers';
import { Header } from '@/components/layout/Header';
import { Footer } from '@/components/layout/Footer';
import { JsonLd } from '@/components/JsonLd';
import { organizationSchema, SITE } from '@/lib/seo';
import { company } from '@/data/company';
import { TinanAI } from '@/components/tinan-ai/TinanAI';

const display = Sora({ subsets: ['latin', 'latin-ext'], weight: ['600', '700', '800'], variable: '--font-display', display: 'swap' });
const body = Manrope({ subsets: ['latin', 'latin-ext'], weight: ['400', '500', '600', '700', '800'], variable: '--font-body', display: 'swap' });

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: { default: 'Tinan Group | Saulės elektrinės ir energijos kaupikliai', template: '%s | Tinan Group' },
  description: 'Saulės elektrinės, hibridinės sistemos, energijos kaupikliai ir inverteriai namams, ūkiams ir verslui. Projektavimas, montavimas ir dokumentai.',
  applicationName: company.name,
  icons: { icon: '/favicon.svg' },
  openGraph: { siteName: company.name, locale: 'lt_LT', type: 'website', images: [{ url: '/images/hero-house.webp' }] },
};

export const viewport: Viewport = { themeColor: '#080808', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="lt" className={`${display.variable} ${body.variable}`}>
      <body className="grain min-h-[100dvh] bg-background">
        <a href="#turinys" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-full focus:bg-[#F28C00] focus:px-4 focus:py-2 focus:font-bold focus:text-black">Pereiti prie turinio</a>
        <JsonLd data={organizationSchema()} />
        <Providers>
          <Header />
          <main id="turinys">{children}</main>
          <Footer />
          <TinanAI />
        </Providers>
      </body>
    </html>
  );
}
