import Link from 'next/link';

export default function NotFound() {
  return (
    <section className="mx-auto flex min-h-[70dvh] max-w-3xl flex-col items-start justify-center px-5 py-24 sm:px-8">
      <span className="accent-line mb-6" />
      <p className="font-mono text-sm font-bold text-[#F28C00]">404</p>
      <h1 className="mt-3 font-display text-5xl font-extrabold uppercase leading-none">Puslapis <span className="text-[#F28C00]">nerastas</span></h1>
      <p className="mt-5 text-lg text-muted-foreground">Galbūt nuoroda pasikeitė. Grįžkite į pradžią arba peržiūrėkite komplektus.</p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link href="/" className="rounded-full bg-[#F28C00] px-6 py-3.5 text-[13px] font-extrabold uppercase tracking-wider text-black">Į pradžią</Link>
        <Link href="/saules-elektrines" className="rounded-full border border-border px-6 py-3.5 text-[13px] font-extrabold uppercase tracking-wider">Komplektai</Link>
      </div>
    </section>
  );
}
