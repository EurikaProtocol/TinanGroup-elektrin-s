import type { MetadataRoute } from 'next';
import { packages } from '@/data/packages';
import { SITE } from '@/lib/seo';

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  const routes = ['', '/saules-elektrines', '/kaupikliai', '/inverteriai', '/kainorastis', '/paslaugos', '/projektai', '/apie-mus', '/kontaktai'];
  return [
    ...routes.map((r) => ({ url: `${SITE}${r || '/'}`, lastModified: now, changeFrequency: 'weekly' as const, priority: r === '' ? 1 : 0.8 })),
    ...packages.map((p) => ({ url: `${SITE}/saules-elektrines/${p.slug}`, lastModified: now, changeFrequency: 'monthly' as const, priority: 0.7 })),
  ];
}
