import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Check, PanelTop, Cpu, BatteryCharging, Construction, ShieldCheck, Activity, Hammer, BadgeCheck, Sun, PiggyBank, Plus } from 'lucide-react';
import { packages, getPackage, packageTitle } from '@/data/packages';
import { packagePrices, computePrice, estimateConfig, formatEur } from '@/data/pricing';
import { PageHero } from '@/components/layout/PageHero';
import { PriceTag } from '@/components/products/PriceTag';
import { PackageCard } from '@/components/packages/PackageCard';
import { LeadButton } from '@/components/forms/LeadModal';
import { JsonLd } from '@/components/JsonLd';
import { pageMeta, SITE } from '@/lib/seo';

export function generateStaticParams() {
  return packages.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = getPackage(slug);
  if (!p) return {};
  return pageMeta({ title: `${p.power} saulės elektrinė ${p.name} | Tinan Group`, description: `${packageTitle(p)}: ${p.tagline}. ${p.components.slice(0, 4).join(', ')}.`, path: `/saules-elektrines/${p.slug}`, image: p.image });
}

export default async function PackagePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const p = getPackage(slug);
  if (!p) notFound();
  const price = computePrice(packagePrices[p.slug]);
  const production = p.kwp ? Math.round(p.kwp * estimateConfig.yieldPerKwp) : null;
  const savings = production && estimateConfig.electricityPrice != null
    ? Math.round(production * (p.battery ? estimateConfig.selfConsumption.withBattery : estimateConfig.selfConsumption.withoutBattery) * estimateConfig.electricityPrice)
    : null;

  const rows = [
    { icon: PanelTop, k: 'Moduliai', v: p.details.modules },
    { icon: Cpu, k: 'Inverteris', v: p.details.inverter },
    { icon: BatteryCharging, k: 'Kaupiklis', v: p.details.battery },
    { icon: Construction, k: 'Konstrukcija', v: p.details.construction },
    { icon: ShieldCheck, k: 'Apsaugos', v: p.details.protections },
    { icon: Activity, k: 'Monitoringas', v: p.details.monitoring },
    { icon: Hammer, k: 'Montavimas', v: p.details.installation },
    { icon: BadgeCheck, k: 'Garantija', v: p.details.warranty },
  ];

  const productSchema = {
    '@context': 'https://schema.org', '@type': 'Product', name: `${packageTitle(p)} saulės elektrinė`, description: p.tagline, image: `${SITE}${p.image}`, brand: { '@type': 'Brand', name: 'TINAN GROUP' },
    ...(price && { offers: { '@type': 'Offer', priceCurrency: 'EUR', price: price.total, availability: 'https://schema.org/InStock', url: `${SITE}/saules-elektrines/${p.slug}` } }),
  };
  const prefill = { systemSize: p.power, solution: packageTitle(p), battery: p.battery, propertyType: p.forProperty[0] };

  return (
    <>
      <JsonLd data={productSchema} />
      <PageHero eyebrow="Saulės elektrinės komplektas" title={p.power} accent={p.name} sub={p.tagline} image={p.slug === '20kw-business' ? '/images/commercial-roof.webp' : '/images/hero-house.webp'} crumbs={[{ name: 'Saulės elektrinės', path: '/saules-elektrines' }, { name: packageTitle(p), path: `/saules-elektrines/${p.slug}` }]} />

      <section className="mx-auto grid max-w-[1440px] gap-10 px-5 py-20 sm:px-8 lg:grid-cols-[1.5fr_1fr]">
        <div>
          <div className="relative aspect-[16/10] overflow-hidden rounded-3xl bg-[#F3F0EB]">
            <Image src={p.image} alt={`${packageTitle(p)} komplekto įrangos iliustracija`} fill sizes="(max-width:1024px) 100vw, 840px" className="object-cover" priority />
            <span className="absolute bottom-4 left-4 rounded-full bg-white/90 px-3 py-1 text-[11px] font-semibold text-muted-foreground">Iliustracija. Konkretūs modeliai — pasiūlyme.</span>
          </div>
          <h2 className="mt-14 font-display text-3xl font-extrabold uppercase">Komplektacija</h2>
          <dl className="mt-6 divide-y divide-border rounded-3xl border border-border bg-white">
            {rows.map((r) => (
              <div key={r.k} className="grid grid-cols-[auto_1fr] gap-4 p-5 sm:grid-cols-[auto_160px_1fr]">
                <r.icon className="h-6 w-6 text-[#F28C00]" strokeWidth={1.6} />
                <dt className="font-bold">{r.k}</dt>
                <dd className="col-span-2 text-muted-foreground sm:col-span-1">{r.v}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            <div className="rounded-3xl bg-[#080808] p-7 text-white">
              <Sun className="h-7 w-7 text-[#F28C00]" strokeWidth={1.5} />
              <p className="mt-4 text-[12px] font-bold uppercase tracking-wider text-white/55">Numatoma metinė gamyba</p>
              <p className="mt-1 font-display text-3xl font-extrabold">{production ? `~${production.toLocaleString('lt-LT')} kWh` : 'Pagal projektą'}</p>
              <p className="mt-2 text-[12.5px] text-white/50">Apytikslis skaičiavimas: {estimateConfig.yieldPerKwp} kWh/kWp per metus. Tikslinama pagal stogą ir orientaciją.</p>
            </div>
            <div className="rounded-3xl bg-[#FFF3E2] p-7">
              <PiggyBank className="h-7 w-7 text-[#F28C00]" strokeWidth={1.5} />
              <p className="mt-4 text-[12px] font-bold uppercase tracking-wider text-muted-foreground">Numatoma metinė nauda</p>
              <p className="mt-1 font-display text-3xl font-extrabold">{savings ? `~${formatEur(savings)}` : 'Skaičiuojama individualiai'}</p>
              <p className="mt-2 text-[12.5px] text-muted-foreground">Priklauso nuo elektros tarifo, suvartojimo profilio ir pasirinkto apskaitos modelio.</p>
            </div>
          </div>

          <h2 className="mt-14 font-display text-3xl font-extrabold uppercase">Papildomi pasirinkimai</h2>
          <ul className="mt-6 grid gap-3 sm:grid-cols-3">
            {p.upgrades.map((u) => <li key={u} className="flex items-start gap-3 rounded-2xl border border-border bg-white p-5 font-semibold"><Plus className="mt-0.5 h-5 w-5 shrink-0 text-[#F28C00]" />{u}</li>)}
          </ul>
        </div>

        <aside className="lg:sticky lg:top-28 lg:self-start">
          <div className="rounded-3xl border border-[#F28C00]/50 bg-white p-7 shadow-[0_30px_60px_-40px_rgba(242,140,0,.6)]">
            <p className="font-display text-2xl font-extrabold uppercase">{p.power} <span className="text-[#F28C00]">{p.name}</span></p>
            <div className="mt-5 border-y border-border py-5"><PriceTag price={packagePrices[p.slug]} /></div>
            <ul className="mt-5 space-y-2.5">{p.components.map((c) => <li key={c} className="flex items-start gap-2.5 text-[14px]"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[#F28C00]" strokeWidth={3} />{c}</li>)}</ul>
            <div className="mt-7 flex flex-col gap-3">
              <LeadButton title={`Pasiūlymas: ${packageTitle(p)}`} prefill={prefill} className="w-full" testId="button-package-detail-offer">Gauti pasiūlymą</LeadButton>
              <Link href="/kontaktai" className="inline-flex items-center justify-center rounded-full border border-border px-6 py-3.5 text-[13px] font-extrabold uppercase tracking-wider hover:border-[#F28C00]" data-testid="link-package-contact">Susisiekti</Link>
            </div>
          </div>
        </aside>
      </section>

      <section className="mx-auto max-w-[1440px] px-5 pb-24 sm:px-8">
        <h2 className="mb-6 font-display text-2xl font-extrabold uppercase">Kiti komplektai</h2>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{packages.filter((x) => x.slug !== p.slug).map((x) => <PackageCard key={x.slug} p={x} />)}</div>
      </section>
    </>
  );
}
