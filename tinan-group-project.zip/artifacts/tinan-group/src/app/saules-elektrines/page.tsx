import Link from 'next/link';
import { packages } from '@/data/packages';
import { PageHero, SectionHead } from '@/components/layout/PageHero';
import { PackageGrid } from '@/components/packages/PackageCard';
import { Calculator } from '@/components/calculator/Calculator';
import { ProcessTimeline, CtaBand } from '@/components/sections/Blocks';
import { LeadButton } from '@/components/forms/LeadModal';
import { JsonLd } from '@/components/JsonLd';
import { pageMeta, serviceSchema } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Saulės elektrinės namams ir verslui | Tinan Group', description: 'Penki saulės elektrinių komplektai: 5 kW START, 10 kW POPULAR, 10 kW HYBRID, 15 kW PRO ir 20+ kW BUSINESS. Montavimas ir pilna komplektacija.', path: '/saules-elektrines' });

export default function Page() {
  return (
    <>
      <JsonLd data={serviceSchema('Saulės elektrinių montavimas', 'Saulės elektrinių projektavimas, įrangos parinkimas ir montavimas namams, ūkiams ir verslui.')} />
      <PageHero eyebrow="Saulės elektrinės" title="Saulės elektrinė," accent="parinkta jūsų namams" sub="Nuo kompaktiško 5 kW sprendimo iki komercinių sistemų. Kiekvienas komplektas — su montavimu ir pilna komplektacija." image="/images/hero-house.webp" crumbs={[{ name: 'Saulės elektrinės', path: '/saules-elektrines' }]}>
        <LeadButton testId="button-solar-hero-offer" />
        <Link href="#skaiciuokle" className="inline-flex items-center rounded-full border border-white/35 px-6 py-3.5 text-[13px] font-extrabold uppercase tracking-wider hover:border-[#F28C00]">Skaičiuoti savo elektrinę</Link>
      </PageHero>
      <section className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
        <SectionHead title={<>Populiariausi saulės elektrinių <span className="text-[#F28C00]">komplektai</span></>} sub="Parinkti pagal realius klientų poreikius. Kaina su montavimu ir pilna komplektacija." />
        <PackageGrid items={packages} />
      </section>
      <section id="skaiciuokle" className="scroll-mt-24 mx-auto max-w-[1440px] px-5 pb-24 sm:px-8"><Calculator /></section>
      <ProcessTimeline />
      <div className="pt-24"><CtaBand /></div>
    </>
  );
}
