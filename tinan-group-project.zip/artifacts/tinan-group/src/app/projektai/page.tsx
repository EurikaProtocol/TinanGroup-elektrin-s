import { Info } from 'lucide-react';
import { PageHero } from '@/components/layout/PageHero';
import { ProjectGallery } from '@/components/sections/ProjectGallery';
import { CtaBand } from '@/components/sections/Blocks';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Projektai | Tinan Group', description: 'Saulės elektrinių sprendimai namams, ūkiams ir verslui bei kaupiklių sistemos.', path: '/projektai', image: '/images/farm.webp' });

export default function Page() {
  return (
    <>
      <PageHero eyebrow="Projektai" title="Sprendimai namams," accent="ūkiams ir verslui" image="/images/farm.webp" crumbs={[{ name: 'Projektai', path: '/projektai' }]} />
      <section className="mx-auto max-w-[1440px] px-5 py-20 sm:px-8">
        <div className="mb-10 flex items-start gap-3 rounded-2xl border border-[#F28C00]/30 bg-[#FFF3E2] p-5 text-[14.5px]">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-[#F28C00]" />
          <p>Šiuo metu rodomos <strong>pavyzdinės konfigūracijos</strong> su iliustraciniais vaizdais. Įgyvendinti TINAN GROUP projektai bus paskelbti gavus klientų sutikimą.</p>
        </div>
        <ProjectGallery />
      </section>
      <CtaBand title="Jūsų objektas gali būti kitas" />
    </>
  );
}
