import Image from 'next/image';
import Link from 'next/link';
import { PiggyBank, BadgeCheck, Wrench, ShieldCheck, ArrowRight, Trophy } from 'lucide-react';
import { t } from '@/i18n';
import { packages } from '@/data/packages';
import { services } from '@/data/services';
import { faq } from '@/data/faq';
import { PackageGrid } from '@/components/packages/PackageCard';
import { Calculator } from '@/components/calculator/Calculator';
import { LeadButton } from '@/components/forms/LeadModal';
import { TrustSection, ProcessTimeline, ServiceCard, FaqList, CtaBand } from '@/components/sections/Blocks';
import { EnergyFlow } from '@/components/sections/EnergyFlow';
import { SectionHead } from '@/components/layout/PageHero';
import { Reveal } from '@/components/Reveal';
import { JsonLd } from '@/components/JsonLd';
import { faqSchema, pageMeta } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Tinan Group | Saulės elektrinės ir energijos kaupikliai', description: 'Išsirinkite saulės elektrinę, kaupiklį ar hibridinę sistemą. Patikima įranga, profesionalus montavimas ir pagalba su ESO bei APVA dokumentais.', path: '/' });

const benefitIcons = [PiggyBank, BadgeCheck, Wrench, ShieldCheck];

export default function HomePage() {
  return (
    <>
      <JsonLd data={faqSchema(faq)} />
      {/* HERO */}
      <section className="relative isolate overflow-hidden bg-[#080808] text-white">
        <Image src="/images/hero-house.webp" alt="Modernus namas su saulės moduliais ant stogo saulėlydžio šviesoje (iliustracija)" fill priority sizes="100vw" className="-z-10 object-cover object-[70%_center]" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-[#080808]/95 via-[#080808]/60 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-t from-[#080808]/90 to-transparent" />
        <div className="mx-auto flex min-h-[calc(100dvh-72px)] max-w-[1440px] flex-col justify-end px-5 pb-10 pt-24 sm:px-8 lg:min-h-[760px] lg:justify-center lg:pb-16">
          <p className="eyebrow hero-in text-white/75">{t.hero.eyebrow}</p>
          <h1 className="font-display hero-in mt-5 max-w-3xl text-[clamp(2.6rem,7.2vw,6rem)] font-extrabold uppercase leading-[0.95]" style={{ animationDelay: '100ms' }}>
            {t.hero.title1}<br /><span className="text-[#F28C00]">{t.hero.title2}</span>
          </h1>
          <p className="hero-in mt-6 max-w-lg text-[17px] leading-relaxed text-white/80 sm:text-[19px]" style={{ animationDelay: '200ms' }}>{t.hero.sub}</p>
          <div className="hero-in mt-9 flex flex-col gap-3 sm:flex-row" style={{ animationDelay: '300ms' }}>
            <LeadButton className="!px-8 !py-4" testId="button-hero-offer" />
            <Link href="#skaiciuokle" className="inline-flex items-center justify-center gap-2 rounded-full border border-white/35 px-8 py-4 text-[13px] font-extrabold uppercase tracking-wider text-white transition hover:border-[#F28C00] hover:text-[#F28C00]" data-testid="link-hero-calc">{t.cta.calc}</Link>
          </div>
          <ul className="hero-in mt-14 grid grid-cols-2 gap-x-6 gap-y-5 border-t border-white/15 pt-8 sm:grid-cols-4 lg:max-w-3xl" style={{ animationDelay: '420ms' }}>
            {t.hero.benefits.map((b, i) => {
              const Icon = benefitIcons[i];
              return <li key={b} className="flex items-center gap-3 text-[14px] font-semibold leading-tight"><Icon className="h-7 w-7 shrink-0 text-[#F28C00]" strokeWidth={1.5} />{b}</li>;
            })}
          </ul>
        </div>
        <p className="absolute bottom-3 right-5 text-[10.5px] text-white/35">Iliustracija</p>
      </section>

      {/* PACKAGES */}
      <section className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8" id="komplektai">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <SectionHead title={<>Populiariausi saulės elektrinių <span className="text-[#F28C00]">komplektai</span></>} sub={t.packages.sub} />
          <span className="mb-12 hidden items-center gap-3 self-start rounded-2xl bg-[#FFF3E2] px-5 py-3 text-[12px] font-bold uppercase tracking-wider lg:inline-flex"><Trophy className="h-5 w-5 text-[#F28C00]" /> Penki komplektai — nuo namo iki verslo</span>
        </div>
        <PackageGrid items={packages} />
        <p className="mt-4 text-[13px] text-muted-foreground lg:hidden">Braukite į šoną, kad pamatytumėte visus komplektus.</p>
      </section>

      {/* CALCULATOR */}
      <section id="skaiciuokle" className="scroll-mt-24 mx-auto max-w-[1440px] px-5 pb-24 sm:px-8"><Calculator /></section>

      <TrustSection />

      {/* BATTERY STORY */}
      <section className="mx-auto grid max-w-[1440px] items-center gap-12 px-5 pb-24 sm:px-8 lg:grid-cols-2">
        <Reveal>
          <SectionHead eyebrow="Energijos kaupikliai" title={<>Sukaupta energija tada, <span className="text-[#F28C00]">kai jos labiausiai reikia</span></>} sub="Hibridinė sistema dieną krauna kaupiklį, vakare maitina namus, o dingus tinklui palaiko svarbiausias grandines." />
          <Link href="/kaupikliai" className="group inline-flex items-center gap-2 font-bold text-[#F28C00]" data-testid="link-home-batteries">Apie kaupiklius <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" /></Link>
        </Reveal>
        <Reveal delay={120}><EnergyFlow /></Reveal>
      </section>

      {/* SERVICES */}
      <section className="bg-[#F3F0EB]">
        <div className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <SectionHead eyebrow="Paslaugos" title={<>Viskas, ko reikia <span className="text-[#F28C00]">vienoje vietoje</span></>} />
            <Link href="/paslaugos" className="mb-12 inline-flex items-center gap-2 font-bold" data-testid="link-home-services">Visos paslaugos <ArrowRight className="h-4 w-4 text-[#F28C00]" /></Link>
          </div>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{services.slice(0, 6).map((s, i) => <ServiceCard key={s.slug} s={s} i={i} />)}</div>
        </div>
      </section>

      <ProcessTimeline />

      <section className="mx-auto grid max-w-[1440px] gap-12 px-5 py-24 sm:px-8 lg:grid-cols-[1fr_1.4fr]">
        <SectionHead eyebrow="DUK" title={<>Dažniausi <span className="text-[#F28C00]">klausimai</span></>} sub="Neradote atsakymo? Parašykite — atsakysime konkrečiai jūsų objektui." />
        <FaqList items={faq} />
      </section>

      <CtaBand />
    </>
  );
}
