import Image from 'next/image';
import { PageHero, SectionHead } from '@/components/layout/PageHero';
import { EnergyFlow } from '@/components/sections/EnergyFlow';
import { ProductCatalog } from '@/components/products/ProductCatalog';
import { CtaBand, FaqList } from '@/components/sections/Blocks';
import { LeadButton } from '@/components/forms/LeadModal';
import { JsonLd } from '@/components/JsonLd';
import { pageMeta, serviceSchema } from '@/lib/seo';
import { faq } from '@/data/faq';

export const metadata = pageMeta({ title: 'Energijos kaupikliai | Tinan Group', description: 'Dyness, KSTAR ir kiti energijos kaupikliai saulės elektrinėms. Saulės energija vakare, naktį ir dingus tinklui.', path: '/kaupikliai', image: '/images/battery-garage.webp' });

const brands = [
  { name: 'Dyness', text: 'Modulinės ličio geležies fosfato kaupiklių sistemos namams ir verslui. Talpa parenkama pagal poreikį.' },
  { name: 'KSTAR', text: 'Kaupikliai ir energijos saugojimo sprendimai didesnėms sistemoms bei komerciniams objektams.' },
  { name: 'Kiti gamintojai', text: 'Dirbame ir su kitais suderinamais kaupikliais — svarbiausia suderinamumas su inverteriu.' },
];

export default function Page() {
  return (
    <>
      <JsonLd data={serviceSchema('Energijos kaupiklių montavimas', 'Energijos kaupiklių parinkimas ir montavimas saulės elektrinėms.')} />
      <PageHero eyebrow="Energijos kaupikliai" title="Sukaupta energija tada," accent="kai jos labiausiai reikia." sub="Kaupiklis padidina savo pagamintos energijos naudojimą ir suteikia ramybę dingus tinklui." image="/images/battery-garage.webp" crumbs={[{ name: 'Kaupikliai', path: '/kaupikliai' }]}>
        <LeadButton title="Kaupiklio pasiūlymas" prefill={{ solution: 'Energijos kaupiklis', battery: true }} testId="button-battery-hero" />
      </PageHero>
      <section className="mx-auto max-w-[1440px] px-5 py-24 sm:px-8">
        <SectionHead center title={<>Kaip <span className="text-[#F28C00]">juda energija</span></>} sub="Diena: saulė, namai, kaupiklis. Naktis: kaupiklis, namai. Dingus tinklui: kaupiklis, rezervinis maitinimas." />
        <EnergyFlow />
      </section>
      <section className="mx-auto max-w-[1440px] px-5 pb-24 sm:px-8">
        <div className="grid gap-5 lg:grid-cols-[1.1fr_1fr_1fr_1fr]">
          <div className="relative min-h-[260px] overflow-hidden rounded-3xl"><Image src="/images/equipment-hybrid.webp" alt="Hibridinis inverteris ir kaupiklio moduliai (iliustracija)" fill sizes="(max-width:1024px) 100vw, 360px" className="object-cover" loading="lazy" /></div>
          {brands.map((b) => (
            <article key={b.name} className="card-lift rounded-3xl border border-border bg-white p-7">
              <span className="accent-line mb-5" />
              <h3 className="font-display text-2xl font-extrabold">{b.name}</h3>
              <p className="mt-3 text-[14.5px] leading-relaxed text-muted-foreground">{b.text}</p>
              <LeadButton variant="light" className="mt-6 !px-4 !py-2.5 !text-[11.5px]" title={`${b.name} kaupiklis`} prefill={{ solution: `${b.name} kaupiklis`, battery: true }} testId={`button-brand-${b.name}`}>Teirautis</LeadButton>
            </article>
          ))}
        </div>
      </section>
      <section className="mx-auto max-w-[1440px] px-5 pb-24 sm:px-8">
        <SectionHead title={<>Kaupiklių <span className="text-[#F28C00]">katalogas</span></>} />
        <ProductCatalog initialCategory="kaupikliai" lockCategory />
      </section>
      <section className="mx-auto max-w-4xl px-5 pb-24 sm:px-8"><FaqList items={faq.slice(1, 5)} /></section>
      <CtaBand title="Pridėkite kaupiklį prie savo elektrinės" />
    </>
  );
}
