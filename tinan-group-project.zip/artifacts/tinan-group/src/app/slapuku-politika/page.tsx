import { LegalPage } from '@/components/layout/LegalPage';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Slapukų politika | Tinan Group', description: 'TINAN GROUP slapukų politika (juodraštis).', path: '/slapuku-politika', noindex: true });

export default function Page() {
  return (
    <LegalPage title="Slapukų politika" path="/slapuku-politika" sections={[
      { h: 'Kas yra slapukai', p: 'Slapukai — maži tekstiniai failai, saugomi jūsų naršyklėje lankantis svetainėje.' },
      { h: 'Kokius slapukus naudojame', p: 'Šiuo metu svetainė nenaudoja analitinių ar reklaminių slapukų. Jei jie bus įdiegti, šis sąrašas bus papildytas ir bus prašoma jūsų sutikimo.' },
      { h: 'Slapukų valdymas', p: 'Slapukus galite ištrinti ar blokuoti savo naršyklės nustatymuose.' },
    ]} />
  );
}
