import { Phone, Mail, MapPin, Clock, MapPinned, ArrowRight } from 'lucide-react';
import { PageHero } from '@/components/layout/PageHero';
import { LeadForm } from '@/components/forms/LeadForm';
import { LeadButton } from '@/components/forms/LeadModal';
import { company, PLACEHOLDER } from '@/data/company';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({ title: 'Kontaktai | Tinan Group', description: 'Susisiekite su TINAN GROUP dėl saulės elektrinės, kaupiklio ar elektros darbų. Užpildykite užklausos formą.', path: '/kontaktai' });

export default function Page() {
  const addr = [company.address.street, company.address.postalCode, company.address.city].filter(Boolean).join(', ');
  const items = [
    { icon: Phone, k: 'Telefonas', v: company.phone, href: company.phone ? `tel:${company.phone.replace(/\s/g, '')}` : undefined },
    { icon: Mail, k: 'El. paštas', v: company.email, href: company.email ? `mailto:${company.email}` : undefined },
    { icon: MapPin, k: 'Adresas', v: addr || null },
    { icon: Clock, k: 'Darbo laikas', v: company.workingHours },
  ];
  return (
    <>
      <PageHero eyebrow="Kontaktai" title="Pakalbėkime apie" accent="jūsų energiją" sub="Užpildykite formą — specialistas susisieks, aptars poreikius ir pateiks pasiūlymą." image="/images/hero-house.webp" crumbs={[{ name: 'Kontaktai', path: '/kontaktai' }]} />
      <section className="mx-auto grid max-w-[1440px] gap-10 px-5 py-20 sm:px-8 lg:grid-cols-[1fr_1.5fr]">
        <div className="flex flex-col gap-4">
          {items.map((it) => (
            <div key={it.k} className="flex items-start gap-4 rounded-3xl border border-border bg-white p-6" data-testid={`contact-${it.k}`}>
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-[#FFF3E2]"><it.icon className="h-5 w-5 text-[#F28C00]" /></span>
              <div>
                <p className="text-[12px] font-bold uppercase tracking-wider text-muted-foreground">{it.k}</p>
                {it.v ? (it.href ? <a href={it.href} className="mt-1 block font-display text-lg font-bold hover:text-[#F28C00]">{it.v}</a> : <p className="mt-1 font-display text-lg font-bold">{it.v}</p>) : <p className="mt-1 text-[15px] text-muted-foreground">{PLACEHOLDER}</p>}
              </div>
            </div>
          ))}
          <div className="flex flex-col gap-3 rounded-3xl bg-[#111] p-5 sm:flex-row">
            <a href={`tel:${company.phone.replace(/\s/g, '')}`} className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-white/20 px-4 py-3 text-sm font-bold text-white hover:border-[#F28C00]"><Phone className="h-4 w-4 text-[#F28C00]" /> Susisiekite su mumis</a>
            <LeadButton className="flex-1 justify-center" testId="button-contact-offer">Gauti pasiūlymą</LeadButton>
          </div>
          <div className="relative min-h-[260px] flex-1 overflow-hidden rounded-3xl border border-border bg-[#F3F0EB]">
            {company.mapEmbedUrl ? (
              <iframe title="TINAN GROUP žemėlapyje" src={company.mapEmbedUrl} className="absolute inset-0 h-full w-full" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
            ) : (
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                <MapPinned className="h-10 w-10 text-[#F28C00]" strokeWidth={1.4} />
                <p className="mt-3 font-display font-bold">Google Maps žemėlapis</p>
                <p className="mt-1 text-[13px] text-muted-foreground">Bus rodomas nurodžius biuro adresą.</p>
              </div>
            )}
          </div>
        </div>
        <div className="rounded-[28px] border border-border bg-white p-6 sm:p-10">
          <span className="accent-line mb-4" />
          <h2 className="font-display text-3xl font-extrabold uppercase">Gauti pasiūlymą</h2>
          <div className="mb-3 mt-2 flex flex-wrap gap-x-5 gap-y-2 text-sm">
            <a href={`tel:${company.phone.replace(/\s/g, '')}`} className="inline-flex items-center gap-2 font-semibold hover:text-[#F28C00]"><Phone className="h-4 w-4 text-[#F28C00]" />{company.phone}</a>
            <a href={`mailto:${company.email}`} className="inline-flex items-center gap-2 font-semibold hover:text-[#F28C00]"><Mail className="h-4 w-4 text-[#F28C00]" />{company.email}</a>
          </div>
          <p className="mb-8 mt-2 text-muted-foreground">Laukai su * yra privalomi.</p>
          <LeadForm idPrefix="contact" />
        </div>
      </section>
    </>
  );
}
