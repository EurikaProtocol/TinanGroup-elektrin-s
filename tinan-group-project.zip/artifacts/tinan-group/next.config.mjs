/** @type {import('next').NextConfig} */
const apiOrigin = process.env.API_SERVER_ORIGIN?.replace(/\/$/, '');

const nextConfig = {
  // Keep preview compilation from overwriting production build manifests.
  distDir: process.env.NODE_ENV === 'development' ? '.next-dev' : '.next',
  transpilePackages: ['@workspace/api-client-react'],
  images: { formats: ['image/avif', 'image/webp'] },
  allowedDevOrigins: ['**.replit.dev', '**.repl.co', '**.replit.app', '127.0.0.1', 'localhost'],
  async redirects() {
    // Only the www host is redirected (308). Preview/other domains are untouched.
    return [
      {
        source: '/:path*',
        has: [{ type: 'host', value: 'www.tinangroup.com' }],
        destination: 'https://tinangroup.com/:path*',
        permanent: true,
      },
    ];
  },
  async rewrites() {
    // Optional: when hosting standalone (e.g. Vercel) with a separately published API.
    // Leave API_SERVER_ORIGIN unset on Replit — the shared proxy routes /api.
    if (!apiOrigin) return [];
    return [{ source: '/api/:path*', destination: `${apiOrigin}/api/:path*` }];
  },
};
export default nextConfig;
