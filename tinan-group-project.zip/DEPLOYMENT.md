# TINAN GROUP — Run and publish

## Commands

Install dependencies from the repository root:

```sh
pnpm install --frozen-lockfile
```

Development (Replit): start the existing website and API workflows. They provide the ports automatically.

```sh
pnpm --filter @workspace/tinan-group run dev
pnpm --filter @workspace/api-server run dev
```

Quality and production build:

```sh
pnpm run typecheck
pnpm --filter @workspace/tinan-group run build
pnpm --filter @workspace/api-server run build
```

Production processes:

```sh
pnpm --filter @workspace/tinan-group run serve
pnpm --filter @workspace/api-server run start
```

Each process requires its own `PORT`. In Replit, use the managed artifact configuration instead of manually starting these commands. The global proxy serves `/api/*` from Express and the rest from Next.js.

## Environment variables

See `.env.example`; it contains names and empty placeholders only.

| Variable | Used by | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | API | Managed PostgreSQL connection; store only as a secret |
| `PORT` | Each server | Injected separately for each service |
| `NODE_ENV` | Both | `production` in production |
| `LOG_LEVEL` | API | Optional logging verbosity |
| `NEXT_PUBLIC_SITE_URL` | Next.js | Canonical domain; defaults to the user-supplied `https://tinangroup.com` |
| `API_SERVER_ORIGIN` | Next.js, external hosting only | HTTPS origin of the separately hosted API; unset on Replit |
| `OPENAI_API_KEY` | API | OpenAI Responses API key; configure as a Replit Secret or backend-host secret only |

Never prefix database credentials or server configuration with `NEXT_PUBLIC_`.

## Replit publishing

The artifact configuration builds and runs both services. Use Publish when the content and launch checklist below are ready. Development schema changes are applied through the Publish flow; do not add startup-time schema migrations.

For custom domains, open Publishing → Domains and add `tinangroup.com`. Copy the exact A and TXT records provided into the domain's DNS settings. Also add `www.tinangroup.com` as a separate domain and use its provided records. Keep the TXT verification records permanently. Replit provisions HTTPS after domain verification.

The application is intended to use `https://tinangroup.com` as canonical, as supplied in the brief. This does not prove ownership or configure the domain. There has been no DNS change or deployment performed by the agent.

## Vercel (preferred external hosting in the brief)

1. Import this repository to Vercel with Next.js project root `artifacts/tinan-group`. Ensure workspace packages outside the root are included.
2. Use pnpm and the repository lockfile. Build with `pnpm --filter @workspace/tinan-group run build` from the repository root, or `pnpm run build` when Vercel executes in the project root.
3. Publish the Express API separately on a Node host with a persistent PostgreSQL database. Build with `pnpm --filter @workspace/api-server run build` and run with `pnpm --filter @workspace/api-server run start`.
4. Set `API_SERVER_ORIGIN` in Vercel to that API's verified HTTPS origin (without a trailing slash). Next.js rewrites `/api/*` to that backend. Set it before building. This keeps browser requests same-origin.
5. Configure `DATABASE_URL` only on the backend host. Use the host's approved migration workflow for a database outside Replit; do not export credentials from this workspace.
6. Add `tinangroup.com` and `www.tinangroup.com` in Vercel's domain settings and apply the exact DNS records Vercel supplies. Do not simultaneously point the same domain at both hosts.
7. Select the apex domain as primary. The application also redirects requests for `www.tinangroup.com` to the apex using a permanent redirect.

If using Cloudflare DNS, enter the hosting provider's records exactly; use DNS-only during verification if the provider instructs it. Use valid origin certificates and Full (strict) when proxying HTTPS; do not use Flexible SSL.

External Vercel/Cloudflare accounts, DNS changes, and certificate verification have not been performed here.

## Enquiries and privacy

Submissions are persisted in PostgreSQL, not sent by email. Authorized project collaborators can view the `energy_leads` table in the database tool. There is deliberately no public leads-reading endpoint.

Before launch, define who monitors incoming enquiries and the retention/deletion schedule. Connect an email/CRM service if notifications are required. No fake customer enquiries or completed installations should be seeded.

## TINAN AI

- Set `OPENAI_API_KEY` as a Replit Secret (or a secret on the API host). The browser never receives it. The API calls OpenAI's Responses API; without the key, chat returns the lead-enquiry fallback.
- Chat endpoint: `POST /api/ai/chat`. It accepts a bounded message history and a public catalog snapshot. It does not persist the transcript server-side.
- Solar sizing and indicative production are calculated by server-side recommendation logic. The yield assumption is `1000 kWh/kWp/year`; this is indicative, not a guaranteed production estimate.
- Unknown package/product prices remain `Individualus pasiūlymas`; preliminary savings/payback are not calculated because the business has not configured a verified electricity price.
- To add or correct public product facts, edit `artifacts/tinan-group/src/data/products.ts` and `packages.ts`. Manufacturer models, specifications, warranty, and stock must be confirmed before publishing.
- To enter customer-facing prices, edit `artifacts/tinan-group/src/data/pricing.ts`; keep all values null until verified. The AI receives customer-facing totals only, never costs or margins.
- To change AI behavior and guardrails, update the server-side prompt in `artifacts/api-server/src/routes/ai.ts`. Keep prices/specifications grounded in site data and do not put the API key in `NEXT_PUBLIC_*`.
- AI lead submissions use the existing `/api/leads` validation, database persistence, consent, and rate limiting. AI transcripts/details are stored only as part of the submitted enquiry message after the visitor consents.

## Launch checklist

- Replace cropped preview logo with the owner's original high-resolution asset when available.
- Confirm company legal identity, phone, email, address, working hours, and social links.
- Add approved equipment models, specifications, warranty terms, stock status, and prices in the structured data configuration.
- Add genuine completed project records and permission to use their photos.
- Review draft privacy/cookie/purchase wording with the business owner or legal adviser; draft pages are not a legal compliance guarantee.
- Confirm calculator assumptions and clearly label output as indicative, not an engineering design or guaranteed saving.
- Decide how staff will receive and manage stored enquiries.
- Confirm domain ownership, apply DNS, verify both domains and HTTPS.
- Run final acceptance testing and a production Lighthouse audit on the published URL. A Lighthouse 90+ score is a target, not an unmeasured claim.
