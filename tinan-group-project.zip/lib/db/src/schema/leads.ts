import { boolean, pgTable, text, timestamp, uuid, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import type { z } from "zod/v4";

export const leadsTable = pgTable("energy_leads", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  city: text("city").notNull(),
  propertyType: text("property_type").notNull(),
  annualConsumption: text("annual_consumption"),
  systemSize: text("system_size"),
  battery: boolean("battery"),
  solution: text("solution"),
  message: text("message"),
  consent: boolean("consent").notNull(),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [index("energy_leads_email_created_idx").on(table.email, table.createdAt)]);

export const insertLeadSchema = createInsertSchema(leadsTable).omit({
  id: true, status: true, createdAt: true,
});
export type InsertLead = z.infer<typeof insertLeadSchema>;
export type Lead = typeof leadsTable.$inferSelect;
