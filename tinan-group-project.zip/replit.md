# TINAN GROUP Energy Platform

Lithuanian solar-energy company website: packages, equipment catalog, recommendations and customer enquiries.

## Run & Operate

- Use managed workflows `artifacts/tinan-group: web` and `artifacts/api-server: API Server`.
- `pnpm run typecheck` — workspace TypeScript checks.
- `pnpm --filter @workspace/tinan-group run build` — Next.js production build.
- `pnpm --filter @workspace/api-server run build` — API build.
- `pnpm --filter @workspace/api-spec run codegen` — regenerate hooks and validators.
- `pnpm --filter @workspace/db run push` — development schema updates only.
- See `DEPLOYMENT.md` for hosting and launch requirements.

## Structure

- `artifacts/tinan-group` — Next.js website and structured editable site content.
- `artifacts/api-server` — Express enquiry endpoint.
- `lib/api-spec` — API contract.
- `lib/api-client-react` / `lib/api-zod` — generated client hooks and validation.
- `lib/db` — PostgreSQL schema; enquiries stored in `energy_leads`.
- `.local/conversation-workspace/files/attached_assets` — original requirements and visual reference.

## Standing Product Requirements

- Primary language is Lithuanian; structure content to allow English later.
- Match the uploaded orange/black TINAN GROUP visual direction. Do not redesign the logo.
- Never invent final prices, manufacturer specifications, company statistics, contacts, testimonials, or completed projects.
- Unknown prices must display “Individualus pasiūlymas”. Unknown business details remain editable placeholders.
- The uploaded concept's example prices and contacts are not verified business data.
- All equipment, pricing, packages, projects, and company content must be centrally editable.
- Admin is a future capability, not a publicly accessible lead-management page.

## Decisions

- Next.js is used instead of the initial Vite scaffold to honor the requested stack and server-render page metadata.
- The shared Express API is used for durable enquiries. Do not simulate successful submissions.
- No email notifications or third-party delivery integration has been configured.
- Enquiry data is private: no unauthenticated list, read, edit, or delete API.
- Lead throttling uses a database transaction per normalized email so multiple server instances cannot bypass it. A separate perimeter bot-protection service can be added before large public campaigns.
- Domain ownership, DNS changes, publishing, verified business content, and approved legal wording require the owner before public launch.
